exports.id = 177;
exports.ids = [177];
exports.modules = {

/***/ 6010:
/***/ ((module) => {

// Exports
module.exports = {
	"recent": "Recents_recent__49PKR",
	"img": "Recents_img__ze3M2",
	"content": "Recents_content__PFZ3Y",
	"title": "Recents_title__YSK7f",
	"detailsList": "Recents_detailsList__VlaLc"
};


/***/ }),

/***/ 9177:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(661);
/* harmony import */ var react_moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Recents_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6010);
/* harmony import */ var _Recents_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_Recents_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Other_Img_Img__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4405);






const Recent = (Recent)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
        href: `/${Recent.type}/${String(Recent.slug)}`,
        as: `/${Recent.type}/${String(Recent.slug)}`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("article", {
            id: Recent.id,
            className: `${(_Recents_module_scss__WEBPACK_IMPORTED_MODULE_5___default().recent)}`,
            style: {
                backgroundImage: `url(https://api.tropicalt.ca${Recent.cover})`
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Other_Img_Img__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    class: (_Recents_module_scss__WEBPACK_IMPORTED_MODULE_5___default().img),
                    url: `${String(Recent.img)}`,
                    placeholder: Recent.cover,
                    alt: `Image for ${String(Recent.title)}`
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `${(_Recents_module_scss__WEBPACK_IMPORTED_MODULE_5___default().content)}`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: (_Recents_module_scss__WEBPACK_IMPORTED_MODULE_5___default().title),
                            children: Recent.title
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: (_Recents_module_scss__WEBPACK_IMPORTED_MODULE_5___default().detailsList),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_Recents_module_scss__WEBPACK_IMPORTED_MODULE_5___default().details),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_moment__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        format: "MMM Do YYYY",
                                        children: Recent.date
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_Recents_module_scss__WEBPACK_IMPORTED_MODULE_5___default().details),
                                    children: Recent.name
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_Recents_module_scss__WEBPACK_IMPORTED_MODULE_5___default().details),
                                    children: Recent.excerpt
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Recent);


/***/ })

};
;