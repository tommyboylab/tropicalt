exports.id = 30;
exports.ids = [30];
exports.modules = {

/***/ 1511:
/***/ ((module) => {

// Exports
module.exports = {
	"error": "Error_error__ALq55"
};


/***/ }),

/***/ 4180:
/***/ ((module) => {

// Exports
module.exports = {
	"load": "Load_load__AGClF"
};


/***/ }),

/***/ 7874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Error_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1511);
/* harmony import */ var _Error_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Error_module_scss__WEBPACK_IMPORTED_MODULE_2__);



const Err = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Error_module_scss__WEBPACK_IMPORTED_MODULE_2___default().error),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: "/static/err.png",
                alt: `You've found an error my friend!'`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                children: "Who you gonna call?"
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Err);


/***/ }),

/***/ 2151:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Load_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4180);
/* harmony import */ var _Load_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Load_module_scss__WEBPACK_IMPORTED_MODULE_2__);



const Loading = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
        className: (_Load_module_scss__WEBPACK_IMPORTED_MODULE_2___default().load),
        src: "/static/load.gif",
        alt: "Loading..."
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loading);


/***/ }),

/***/ 4617:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);



const Meta = ({ title , excerpt , imgUrl , url  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "title",
                content: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "description",
                content: excerpt
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:type",
                content: "website"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:url",
                content: `https://tropicalt.ca${url}`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:title",
                content: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:description",
                content: excerpt
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:image",
                content: `https://api.tropicalt.ca${String(imgUrl)}`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "twitter:card",
                content: "summary_large_image"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "twitter:url",
                content: `https://tropicalt.ca${url}`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "twitter:title",
                content: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "twitter:description",
                content: excerpt
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "twitter:image",
                content: `https://api.tropicalt.ca${String(imgUrl)}`
            })
        ]
    });
Meta.displayName = "MetaTags";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Meta);


/***/ }),

/***/ 1265:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "P": () => (/* reexport */ gql)
});

;// CONCATENATED MODULE: ./gql/graphql.ts
var Enum_Album_Location;
(function(Enum_Album_Location) {
    Enum_Album_Location["Bahamas"] = "Bahamas";
    Enum_Album_Location["Canada"] = "Canada";
    Enum_Album_Location["Czechia"] = "Czechia";
    Enum_Album_Location["Germany"] = "Germany";
    Enum_Album_Location["Hungary"] = "Hungary";
    Enum_Album_Location["Italy"] = "Italy";
    Enum_Album_Location["Spain"] = "Spain";
    Enum_Album_Location["Uk"] = "UK";
    Enum_Album_Location["Usa"] = "USA";
})(Enum_Album_Location || (Enum_Album_Location = {}));
var Enum_Componentblogtag_Name;
(function(Enum_Componentblogtag_Name) {
    Enum_Componentblogtag_Name["Css"] = "CSS";
    Enum_Componentblogtag_Name["Diy"] = "DIY";
    Enum_Componentblogtag_Name["Html"] = "HTML";
    Enum_Componentblogtag_Name["Js"] = "JS";
    Enum_Componentblogtag_Name["Life"] = "Life";
    Enum_Componentblogtag_Name["Photography"] = "Photography";
    Enum_Componentblogtag_Name["Tech"] = "Tech";
    Enum_Componentblogtag_Name["Work"] = "Work";
})(Enum_Componentblogtag_Name || (Enum_Componentblogtag_Name = {}));
var PublicationState;
(function(PublicationState) {
    PublicationState["Live"] = "LIVE";
    PublicationState["Preview"] = "PREVIEW";
})(PublicationState || (PublicationState = {}));
const AboutCardFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "AboutCardFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Query"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "about"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "AboutCard"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "Tagline"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "Extension"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "Img"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "img"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "data"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "attributes"
                                                                                                            },
                                                                                                            "selectionSet": {
                                                                                                                "kind": "SelectionSet",
                                                                                                                "selections": [
                                                                                                                    {
                                                                                                                        "kind": "Field",
                                                                                                                        "name": {
                                                                                                                            "kind": "Name",
                                                                                                                            "value": "url"
                                                                                                                        }
                                                                                                                    },
                                                                                                                    {
                                                                                                                        "kind": "Field",
                                                                                                                        "name": {
                                                                                                                            "kind": "Name",
                                                                                                                            "value": "hash"
                                                                                                                        }
                                                                                                                    }
                                                                                                                ]
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const ArticleListFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "ArticleListFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Query"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "list"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "articles"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "sort"
                                },
                                "value": {
                                    "kind": "StringValue",
                                    "value": "Published:desc",
                                    "block": false
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "pagination"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "start"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "start"
                                                }
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "limit"
                                            },
                                            "value": {
                                                "kind": "IntValue",
                                                "value": "7"
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Slug"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Tagline"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Published"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Author"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "data"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "attributes"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "username"
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Cover"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "img"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "data"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "attributes"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "url"
                                                                                                            }
                                                                                                        },
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "hash"
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const SidebarArticlesFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "SidebarArticlesFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Query"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "alias": {
                            "kind": "Name",
                            "value": "sidebar"
                        },
                        "name": {
                            "kind": "Name",
                            "value": "articles"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "sort"
                                },
                                "value": {
                                    "kind": "StringValue",
                                    "value": "Published:desc",
                                    "block": false
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "pagination"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "limit"
                                            },
                                            "value": {
                                                "kind": "IntValue",
                                                "value": "4"
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Slug"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Tagline"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Published"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Author"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "data"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "attributes"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "username"
                                                                                                }
                                                                                            },
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "Img"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "img"
                                                                                                            },
                                                                                                            "selectionSet": {
                                                                                                                "kind": "SelectionSet",
                                                                                                                "selections": [
                                                                                                                    {
                                                                                                                        "kind": "Field",
                                                                                                                        "name": {
                                                                                                                            "kind": "Name",
                                                                                                                            "value": "data"
                                                                                                                        },
                                                                                                                        "selectionSet": {
                                                                                                                            "kind": "SelectionSet",
                                                                                                                            "selections": [
                                                                                                                                {
                                                                                                                                    "kind": "Field",
                                                                                                                                    "name": {
                                                                                                                                        "kind": "Name",
                                                                                                                                        "value": "id"
                                                                                                                                    }
                                                                                                                                },
                                                                                                                                {
                                                                                                                                    "kind": "Field",
                                                                                                                                    "name": {
                                                                                                                                        "kind": "Name",
                                                                                                                                        "value": "attributes"
                                                                                                                                    },
                                                                                                                                    "selectionSet": {
                                                                                                                                        "kind": "SelectionSet",
                                                                                                                                        "selections": [
                                                                                                                                            {
                                                                                                                                                "kind": "Field",
                                                                                                                                                "name": {
                                                                                                                                                    "kind": "Name",
                                                                                                                                                    "value": "url"
                                                                                                                                                }
                                                                                                                                            },
                                                                                                                                            {
                                                                                                                                                "kind": "Field",
                                                                                                                                                "name": {
                                                                                                                                                    "kind": "Name",
                                                                                                                                                    "value": "hash"
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        ]
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            ]
                                                                                                                        }
                                                                                                                    }
                                                                                                                ]
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Cover"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "img"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "data"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "id"
                                                                                                }
                                                                                            },
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "attributes"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "url"
                                                                                                            }
                                                                                                        },
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "hash"
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const AlbumFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "AlbumFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Query"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "albums"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "sort"
                                },
                                "value": {
                                    "kind": "StringValue",
                                    "value": "Date:desc",
                                    "block": false
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Name"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Tagline"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Slug"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Date"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Location"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Photographer"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "data"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "attributes"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "username"
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Cover"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "img"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "data"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "attributes"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "url"
                                                                                                            }
                                                                                                        },
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "hash"
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "GPhotoId"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const BiographyFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "BiographyFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Query"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "usersPermissionsUser"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "id"
                                },
                                "value": {
                                    "kind": "IntValue",
                                    "value": "1"
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Biography"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Img"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "img"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "data"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "id"
                                                                                                }
                                                                                            },
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "attributes"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "url"
                                                                                                            }
                                                                                                        },
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "hash"
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const HeroFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "HeroFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Query"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "home"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Hero"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "Img"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "img"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "data"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "attributes"
                                                                                                            },
                                                                                                            "selectionSet": {
                                                                                                                "kind": "SelectionSet",
                                                                                                                "selections": [
                                                                                                                    {
                                                                                                                        "kind": "Field",
                                                                                                                        "name": {
                                                                                                                            "kind": "Name",
                                                                                                                            "value": "url"
                                                                                                                        }
                                                                                                                    },
                                                                                                                    {
                                                                                                                        "kind": "Field",
                                                                                                                        "name": {
                                                                                                                            "kind": "Name",
                                                                                                                            "value": "hash"
                                                                                                                        }
                                                                                                                    }
                                                                                                                ]
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "Caption"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const RecentAlbumsFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "RecentAlbumsFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Query"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "albums"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "sort"
                                },
                                "value": {
                                    "kind": "StringValue",
                                    "value": "Date:desc",
                                    "block": false
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "pagination"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "start"
                                            },
                                            "value": {
                                                "kind": "IntValue",
                                                "value": "0"
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "limit"
                                            },
                                            "value": {
                                                "kind": "IntValue",
                                                "value": "4"
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Slug"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Name"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Tagline"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Date"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Location"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Photographer"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "data"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "attributes"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "username"
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Cover"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "img"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "data"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "attributes"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "url"
                                                                                                            }
                                                                                                        },
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "hash"
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const RecentArticlesFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "RecentArticlesFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Query"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "articles"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "sort"
                                },
                                "value": {
                                    "kind": "StringValue",
                                    "value": "Published:desc",
                                    "block": false
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "pagination"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "start"
                                            },
                                            "value": {
                                                "kind": "IntValue",
                                                "value": "0"
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "limit"
                                            },
                                            "value": {
                                                "kind": "IntValue",
                                                "value": "3"
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Slug"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Tagline"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Published"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Author"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "data"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "attributes"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "username"
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Cover"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "img"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "data"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "attributes"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "url"
                                                                                                            }
                                                                                                        },
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "hash"
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const NavigationFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "NavigationFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Query"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "navLink"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Link"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "Name"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "URL"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const NewNavigationFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "NewNavigationFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Query"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "navLink"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Link"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "id"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "Name"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "URL"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const ContactFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "ContactFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Resume"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "Address"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "Phone"
                        }
                    }
                ]
            }
        }
    ]
};
const EducationFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "EducationFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Resume"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "Education"
                        }
                    }
                ]
            }
        }
    ]
};
const HobbiesFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "HobbiesFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Resume"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "Hobbies"
                        }
                    }
                ]
            }
        }
    ]
};
const HighlightImgFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "HighlightImgFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Resume"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "Img"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "img"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "data"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "id"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "attributes"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "url"
                                                                        }
                                                                    },
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "hash"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const ResumeEmailFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "ResumeEmailFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Resume"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "email"
                        }
                    }
                ]
            }
        }
    ]
};
const SkillsFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "SkillsFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Resume"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "Skills"
                        }
                    }
                ]
            }
        }
    ]
};
const WorkExpFragmentFragmentDoc = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "FragmentDefinition",
            "name": {
                "kind": "Name",
                "value": "WorkExpFragment"
            },
            "typeCondition": {
                "kind": "NamedType",
                "name": {
                    "kind": "Name",
                    "value": "Resume"
                }
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "Experience"
                        }
                    }
                ]
            }
        }
    ]
};
const UpdateCommentLikesDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "updateCommentLikes"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "commentId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "likes"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "Int"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "dislikes"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "Int"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "updateComment"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "id"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "commentId"
                                    }
                                }
                            },
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "data"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "Likes"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "UserId"
                                                        },
                                                        "value": {
                                                            "kind": "Variable",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "likes"
                                                            }
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "Dislikes"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "UserId"
                                                        },
                                                        "value": {
                                                            "kind": "Variable",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "dislikes"
                                                            }
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Likes"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "UserId"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Dislikes"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "UserId"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const GetUserDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "getUser"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "userId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "usersPermissionsUser"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "id"
                                },
                                "value": {
                                    "kind": "Variable",
                                    "name": {
                                        "kind": "Name",
                                        "value": "userId"
                                    }
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "username"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Img"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "img"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "data"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "id"
                                                                                                }
                                                                                            },
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "attributes"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "url"
                                                                                                            }
                                                                                                        },
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "hash"
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const AddCommentDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "AddComment"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "articleId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "userId"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "ID"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "content"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "date"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "DateTime"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "parentId"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "ID"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "createComment"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "data"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "article"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "articleId"
                                                }
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "Author"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "userId"
                                                }
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "Content"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "content"
                                                }
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "Published"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "date"
                                                }
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "Parent"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "parentId"
                                                }
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Content"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Author"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "data"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "id"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "article"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "data"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "id"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Published"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Parent"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "data"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "id"
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const CommentsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "Comments"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "slug"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "String"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "me"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "id"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "comments"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filters"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "article"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "Slug"
                                                        },
                                                        "value": {
                                                            "kind": "ObjectValue",
                                                            "fields": [
                                                                {
                                                                    "kind": "ObjectField",
                                                                    "name": {
                                                                        "kind": "Name",
                                                                        "value": "eq"
                                                                    },
                                                                    "value": {
                                                                        "kind": "Variable",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "slug"
                                                                        }
                                                                    }
                                                                }
                                                            ]
                                                        }
                                                    }
                                                ]
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "Parent"
                                            },
                                            "value": {
                                                "kind": "NullValue"
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "article"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "data"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "id"
                                                                                    }
                                                                                },
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "attributes"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "Slug"
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Author"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "data"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "attributes"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "username"
                                                                                                }
                                                                                            },
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "Img"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "img"
                                                                                                            },
                                                                                                            "selectionSet": {
                                                                                                                "kind": "SelectionSet",
                                                                                                                "selections": [
                                                                                                                    {
                                                                                                                        "kind": "Field",
                                                                                                                        "name": {
                                                                                                                            "kind": "Name",
                                                                                                                            "value": "data"
                                                                                                                        },
                                                                                                                        "selectionSet": {
                                                                                                                            "kind": "SelectionSet",
                                                                                                                            "selections": [
                                                                                                                                {
                                                                                                                                    "kind": "Field",
                                                                                                                                    "name": {
                                                                                                                                        "kind": "Name",
                                                                                                                                        "value": "attributes"
                                                                                                                                    },
                                                                                                                                    "selectionSet": {
                                                                                                                                        "kind": "SelectionSet",
                                                                                                                                        "selections": [
                                                                                                                                            {
                                                                                                                                                "kind": "Field",
                                                                                                                                                "name": {
                                                                                                                                                    "kind": "Name",
                                                                                                                                                    "value": "url"
                                                                                                                                                }
                                                                                                                                            },
                                                                                                                                            {
                                                                                                                                                "kind": "Field",
                                                                                                                                                "name": {
                                                                                                                                                    "kind": "Name",
                                                                                                                                                    "value": "hash"
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        ]
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            ]
                                                                                                                        }
                                                                                                                    }
                                                                                                                ]
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Content"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Children"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "data"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "attributes"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "Content"
                                                                                                }
                                                                                            },
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "createdAt"
                                                                                                }
                                                                                            },
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "updatedAt"
                                                                                                }
                                                                                            },
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "Likes"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "UserId"
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            },
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "Dislikes"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "UserId"
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            },
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "Author"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "data"
                                                                                                            },
                                                                                                            "selectionSet": {
                                                                                                                "kind": "SelectionSet",
                                                                                                                "selections": [
                                                                                                                    {
                                                                                                                        "kind": "Field",
                                                                                                                        "name": {
                                                                                                                            "kind": "Name",
                                                                                                                            "value": "attributes"
                                                                                                                        },
                                                                                                                        "selectionSet": {
                                                                                                                            "kind": "SelectionSet",
                                                                                                                            "selections": [
                                                                                                                                {
                                                                                                                                    "kind": "Field",
                                                                                                                                    "name": {
                                                                                                                                        "kind": "Name",
                                                                                                                                        "value": "username"
                                                                                                                                    }
                                                                                                                                },
                                                                                                                                {
                                                                                                                                    "kind": "Field",
                                                                                                                                    "name": {
                                                                                                                                        "kind": "Name",
                                                                                                                                        "value": "Img"
                                                                                                                                    },
                                                                                                                                    "selectionSet": {
                                                                                                                                        "kind": "SelectionSet",
                                                                                                                                        "selections": [
                                                                                                                                            {
                                                                                                                                                "kind": "Field",
                                                                                                                                                "name": {
                                                                                                                                                    "kind": "Name",
                                                                                                                                                    "value": "img"
                                                                                                                                                },
                                                                                                                                                "selectionSet": {
                                                                                                                                                    "kind": "SelectionSet",
                                                                                                                                                    "selections": [
                                                                                                                                                        {
                                                                                                                                                            "kind": "Field",
                                                                                                                                                            "name": {
                                                                                                                                                                "kind": "Name",
                                                                                                                                                                "value": "data"
                                                                                                                                                            },
                                                                                                                                                            "selectionSet": {
                                                                                                                                                                "kind": "SelectionSet",
                                                                                                                                                                "selections": [
                                                                                                                                                                    {
                                                                                                                                                                        "kind": "Field",
                                                                                                                                                                        "name": {
                                                                                                                                                                            "kind": "Name",
                                                                                                                                                                            "value": "attributes"
                                                                                                                                                                        },
                                                                                                                                                                        "selectionSet": {
                                                                                                                                                                            "kind": "SelectionSet",
                                                                                                                                                                            "selections": [
                                                                                                                                                                                {
                                                                                                                                                                                    "kind": "Field",
                                                                                                                                                                                    "name": {
                                                                                                                                                                                        "kind": "Name",
                                                                                                                                                                                        "value": "url"
                                                                                                                                                                                    }
                                                                                                                                                                                },
                                                                                                                                                                                {
                                                                                                                                                                                    "kind": "Field",
                                                                                                                                                                                    "name": {
                                                                                                                                                                                        "kind": "Name",
                                                                                                                                                                                        "value": "hash"
                                                                                                                                                                                    }
                                                                                                                                                                                }
                                                                                                                                                                            ]
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                ]
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    ]
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        ]
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            ]
                                                                                                                        }
                                                                                                                    }
                                                                                                                ]
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "createdAt"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "updatedAt"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Likes"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "UserId"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Dislikes"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "UserId"
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const AddEmailDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "mutation",
            "name": {
                "kind": "Name",
                "value": "AddEmail"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "name"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "email"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                },
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "message"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "createContact"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "data"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "Name"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "name"
                                                }
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "Email"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "email"
                                                }
                                            }
                                        },
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "Message"
                                            },
                                            "value": {
                                                "kind": "Variable",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "message"
                                                }
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Name"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Email"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Message"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const GetAlbumsDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "getAlbums"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "slug"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "String"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "albums"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filters"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "Slug"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "eq"
                                                        },
                                                        "value": {
                                                            "kind": "Variable",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "slug"
                                                            }
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Name"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Tagline"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Slug"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Cover"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "img"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "data"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "attributes"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "url"
                                                                                                            }
                                                                                                        },
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "hash"
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "GPhotoId"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const GetAboutPageDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "GetAboutPage"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "NavigationFragment"
                        }
                    },
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "AboutCardFragment"
                        }
                    }
                ]
            }
        },
        ...NavigationFragmentFragmentDoc.definitions,
        ...AboutCardFragmentFragmentDoc.definitions
    ]
};
const GetAlbumPageDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "GetAlbumPage"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "NavigationFragment"
                        }
                    },
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "AlbumFragment"
                        }
                    }
                ]
            }
        },
        ...NavigationFragmentFragmentDoc.definitions,
        ...AlbumFragmentFragmentDoc.definitions
    ]
};
const GetArticlesDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "GetArticles"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "start"
                        }
                    },
                    "type": {
                        "kind": "NonNullType",
                        "type": {
                            "kind": "NamedType",
                            "name": {
                                "kind": "Name",
                                "value": "Int"
                            }
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "NavigationFragment"
                        }
                    },
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "ArticleListFragment"
                        }
                    },
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "SidebarArticlesFragment"
                        }
                    }
                ]
            }
        },
        ...NavigationFragmentFragmentDoc.definitions,
        ...ArticleListFragmentFragmentDoc.definitions,
        ...SidebarArticlesFragmentFragmentDoc.definitions
    ]
};
const ArticlesDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "Articles"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "articles"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Slug"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        }
    ]
};
const ArticleDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "Article"
            },
            "variableDefinitions": [
                {
                    "kind": "VariableDefinition",
                    "variable": {
                        "kind": "Variable",
                        "name": {
                            "kind": "Name",
                            "value": "slug"
                        }
                    },
                    "type": {
                        "kind": "NamedType",
                        "name": {
                            "kind": "Name",
                            "value": "String"
                        }
                    }
                }
            ],
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "NavigationFragment"
                        }
                    },
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "articles"
                        },
                        "arguments": [
                            {
                                "kind": "Argument",
                                "name": {
                                    "kind": "Name",
                                    "value": "filters"
                                },
                                "value": {
                                    "kind": "ObjectValue",
                                    "fields": [
                                        {
                                            "kind": "ObjectField",
                                            "name": {
                                                "kind": "Name",
                                                "value": "Slug"
                                            },
                                            "value": {
                                                "kind": "ObjectValue",
                                                "fields": [
                                                    {
                                                        "kind": "ObjectField",
                                                        "name": {
                                                            "kind": "Name",
                                                            "value": "eq"
                                                        },
                                                        "value": {
                                                            "kind": "Variable",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "slug"
                                                            }
                                                        }
                                                    }
                                                ]
                                            }
                                        }
                                    ]
                                }
                            }
                        ],
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Slug"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Title"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Tagline"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Published"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Content"
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Author"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "data"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "attributes"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "username"
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        },
                                                        {
                                                            "kind": "Field",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "Cover"
                                                            },
                                                            "selectionSet": {
                                                                "kind": "SelectionSet",
                                                                "selections": [
                                                                    {
                                                                        "kind": "Field",
                                                                        "name": {
                                                                            "kind": "Name",
                                                                            "value": "img"
                                                                        },
                                                                        "selectionSet": {
                                                                            "kind": "SelectionSet",
                                                                            "selections": [
                                                                                {
                                                                                    "kind": "Field",
                                                                                    "name": {
                                                                                        "kind": "Name",
                                                                                        "value": "data"
                                                                                    },
                                                                                    "selectionSet": {
                                                                                        "kind": "SelectionSet",
                                                                                        "selections": [
                                                                                            {
                                                                                                "kind": "Field",
                                                                                                "name": {
                                                                                                    "kind": "Name",
                                                                                                    "value": "attributes"
                                                                                                },
                                                                                                "selectionSet": {
                                                                                                    "kind": "SelectionSet",
                                                                                                    "selections": [
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "url"
                                                                                                            }
                                                                                                        },
                                                                                                        {
                                                                                                            "kind": "Field",
                                                                                                            "name": {
                                                                                                                "kind": "Name",
                                                                                                                "value": "hash"
                                                                                                            }
                                                                                                        }
                                                                                                    ]
                                                                                                }
                                                                                            }
                                                                                        ]
                                                                                    }
                                                                                }
                                                                            ]
                                                                        }
                                                                    }
                                                                ]
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "SidebarArticlesFragment"
                        }
                    }
                ]
            }
        },
        ...NavigationFragmentFragmentDoc.definitions,
        ...SidebarArticlesFragmentFragmentDoc.definitions
    ]
};
const GetContactPageDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "GetContactPage"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "NavigationFragment"
                        }
                    }
                ]
            }
        },
        ...NavigationFragmentFragmentDoc.definitions
    ]
};
const GetHomePageDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "GetHomePage"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "NavigationFragment"
                        }
                    },
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "HeroFragment"
                        }
                    },
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "BiographyFragment"
                        }
                    },
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "RecentArticlesFragment"
                        }
                    },
                    {
                        "kind": "FragmentSpread",
                        "name": {
                            "kind": "Name",
                            "value": "RecentAlbumsFragment"
                        }
                    }
                ]
            }
        },
        ...NavigationFragmentFragmentDoc.definitions,
        ...HeroFragmentFragmentDoc.definitions,
        ...BiographyFragmentFragmentDoc.definitions,
        ...RecentArticlesFragmentFragmentDoc.definitions,
        ...RecentAlbumsFragmentFragmentDoc.definitions
    ]
};
const GetResumeQueryDocument = {
    "kind": "Document",
    "definitions": [
        {
            "kind": "OperationDefinition",
            "operation": "query",
            "name": {
                "kind": "Name",
                "value": "GetResumeQuery"
            },
            "selectionSet": {
                "kind": "SelectionSet",
                "selections": [
                    {
                        "kind": "Field",
                        "name": {
                            "kind": "Name",
                            "value": "resume"
                        },
                        "selectionSet": {
                            "kind": "SelectionSet",
                            "selections": [
                                {
                                    "kind": "Field",
                                    "name": {
                                        "kind": "Name",
                                        "value": "data"
                                    },
                                    "selectionSet": {
                                        "kind": "SelectionSet",
                                        "selections": [
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "id"
                                                }
                                            },
                                            {
                                                "kind": "Field",
                                                "name": {
                                                    "kind": "Name",
                                                    "value": "attributes"
                                                },
                                                "selectionSet": {
                                                    "kind": "SelectionSet",
                                                    "selections": [
                                                        {
                                                            "kind": "FragmentSpread",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "ContactFragment"
                                                            }
                                                        },
                                                        {
                                                            "kind": "FragmentSpread",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "WorkExpFragment"
                                                            }
                                                        },
                                                        {
                                                            "kind": "FragmentSpread",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "EducationFragment"
                                                            }
                                                        },
                                                        {
                                                            "kind": "FragmentSpread",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "SkillsFragment"
                                                            }
                                                        },
                                                        {
                                                            "kind": "FragmentSpread",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "HighlightImgFragment"
                                                            }
                                                        },
                                                        {
                                                            "kind": "FragmentSpread",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "HobbiesFragment"
                                                            }
                                                        },
                                                        {
                                                            "kind": "FragmentSpread",
                                                            "name": {
                                                                "kind": "Name",
                                                                "value": "ResumeEmailFragment"
                                                            }
                                                        }
                                                    ]
                                                }
                                            }
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                ]
            }
        },
        ...ContactFragmentFragmentDoc.definitions,
        ...WorkExpFragmentFragmentDoc.definitions,
        ...EducationFragmentFragmentDoc.definitions,
        ...SkillsFragmentFragmentDoc.definitions,
        ...HighlightImgFragmentFragmentDoc.definitions,
        ...HobbiesFragmentFragmentDoc.definitions,
        ...ResumeEmailFragmentFragmentDoc.definitions
    ]
};

;// CONCATENATED MODULE: ./gql/gql.ts
/* eslint-disable */ 
const documents = {
    "\n  fragment AboutCardFragment on Query {\n  about {\n    data {\n      attributes {\n        AboutCard {\n          id\n          Tagline\n          Extension\n          Img {\n            img {\n              data {\n                attributes {\n                  url\n                  hash\n                }\n              }\n            }\n          }\n        }\n      }\n    }\n  }\n  }\n": AboutCardFragmentFragmentDoc,
    '\n  fragment ArticleListFragment on Query {\n    list: articles(sort: "Published:desc", pagination: { start: $start, limit: 7 }) {\n      data {\n        id\n        attributes {\n          Slug\n          Title\n          Tagline\n          Published\n          Author {\n            data {\n              attributes {\n                username\n              }\n            }\n          }\n          Cover {\n            img {\n              data {\n                attributes {\n                  url\n                  hash\n                }\n              }\n            }\n          }\n        }\n      }\n    }\n  }\n': ArticleListFragmentFragmentDoc,
    "\nmutation updateCommentLikes(\n  $commentId: ID!\n  $likes: Int!\n  $dislikes: Int!\n) {\n  updateComment(\n    id: $commentId\n    data: { Likes: { UserId: $likes }, Dislikes: { UserId: $dislikes } }\n  ) {\n    data {\n      id\n      attributes {\n        Likes {\n          UserId\n        }\n        Dislikes {\n          UserId\n        }\n      }\n    }\n  }\n}\n\n": UpdateCommentLikesDocument,
    "\nquery getUser($userId: ID!) {\n  usersPermissionsUser(id: $userId) {\n    data {\n      attributes {\n        username\n        Img {\n          img {\n            data {\n              id\n              attributes {\n                url\n                hash\n              }\n            }\n          }\n        }\n      }\n    }\n  }\n}": GetUserDocument,
    "\n  mutation AddComment($articleId: ID!, $userId: ID!, $content: String!, $date: DateTime!, $parentId: ID) {\n    createComment(\n      data: { article: $articleId, Author: $userId, Content: $content, Published: $date, Parent: $parentId }\n    ) {\n      data {\n        id\n        attributes {\n          Content\n          Author {\n            data {\n              id\n            }\n          }\n          article {\n            data {\n              id\n            }\n          }\n          Published\n          Parent {\n            data {\n              id\n            }\n          }\n        }\n      }\n    }\n  }\n": AddCommentDocument,
    "\n query Comments($slug: String) {\n  me {\n    id\n  }\n  comments(filters: { article: { Slug: { eq: $slug } }, Parent: null }) {\n    data {\n      id\n      attributes {\n        article {\n          data {\n            id\n            attributes {\n              Slug\n            }\n          }\n        }\n        Author {\n          data {\n            attributes {\n              username\n              Img {\n                img {\n                  data {\n                    attributes {\n                      url\n                      hash\n                    }\n                  }\n                }\n              }\n            }\n          }\n        }\n        Content\n        Children {\n          data {\n            attributes {\n              Content\n              createdAt\n              updatedAt\n              Likes {\n                UserId\n              }\n              Dislikes {\n                UserId\n              }\n              Author {\n                data {\n                  attributes {\n                    username\n                    Img {\n                      img {\n                        data {\n                          attributes {\n                            url\n                            hash\n                          }\n                        }\n                      }\n                    }\n                  }\n                }\n              }\n            }\n          }\n        }\n        createdAt\n        updatedAt\n        Likes {\n          UserId\n        }\n        Dislikes {\n          UserId\n        }\n      }\n    }\n  }\n}\n": CommentsDocument,
    '\n fragment SidebarArticlesFragment on Query {\n  sidebar: articles(sort: "Published:desc", pagination: { limit: 4 }) {\n    data {\n      id\n      attributes {\n        Slug\n        Title\n        Tagline\n        Published\n        Author {\n          data {\n            attributes {\n              username\n              Img {\n                img {\n                  data {\n                    id\n                    attributes {\n                      url\n                      hash\n                    }\n                  }\n                }\n              }\n            }\n          }\n        }\n        Cover {\n          img {\n            data {\n              id\n              attributes {\n                url\n                hash\n              }\n            }\n          }\n        }\n      }\n    }\n  }\n}\n': SidebarArticlesFragmentFragmentDoc,
    "\nmutation AddEmail($name: String!, $email: String!, $message: String!) {\n  createContact(data: { Name: $name, Email: $email, Message: $message }) {\n    data {\n      attributes {\n        Name\n        Email\n        Message\n      }\n    }\n  }\n}\n": AddEmailDocument,
    "\n  query getAlbums($slug: String!) {\n    albums(filters: { Slug: { eq: $slug } }) {\n      data {\n        attributes {\n          Name\n          Tagline\n          Slug\n          Cover {\n            img {\n              data {\n                attributes {\n                  url\n                  hash\n                }\n              }\n            }\n          }\n          GPhotoId\n        }\n      }\n    }\n  }\n": GetAlbumsDocument,
    '\n  fragment AlbumFragment on Query {\n    albums(sort: "Date:desc") {\n      data {\n      id\n        attributes {\n          Name\n          Tagline\n          Slug\n          Date\n          Location\n          Photographer {\n            data {\n              attributes {\n                username\n              }\n            }\n          }\n          Cover {\n            img {\n              data {\n                attributes {\n                  url\n                  hash\n                }\n              }\n            }\n          }\n          GPhotoId\n        }\n      }\n    }\n  }\n': AlbumFragmentFragmentDoc,
    "\n  fragment BiographyFragment on Query {\nusersPermissionsUser(id:1){\n  data{\n    id\n    attributes{\n      Biography\n      Img{\n        img{\n          data{\n            id\n            attributes{\n              url\n              hash\n            }\n          }\n        }\n      }\n    }\n  }\n}}": BiographyFragmentFragmentDoc,
    "\n  fragment HeroFragment on Query {\n  home {\n    data {\n      attributes {\n        Hero {\n          id\n          Img {\n            img {\n              data {\n                attributes {\n                  url\n                  hash\n                }\n              }\n            }\n          }\n          Caption\n        }\n      }\n    }\n  }\n}\n": HeroFragmentFragmentDoc,
    '\n  fragment RecentAlbumsFragment on Query {\n      albums(sort: "Date:desc", pagination: { start: 0, limit: 4 }) {\n    data {\n      id\n      attributes {\n        Slug\n        Name\n        Tagline\n        Date\n        Location\n        Photographer {\n          data {\n            attributes {\n              username\n            }\n          }\n        }\n        Cover {\n          img {\n            data {\n              attributes {\n                url\n                hash\n              }\n            }\n          }\n        }\n      }\n    }\n  }\n  }\n': RecentAlbumsFragmentFragmentDoc,
    '\n  fragment RecentArticlesFragment on Query {\n articles(sort:"Published:desc", pagination: { start: 0, limit: 3}){\n    data {\n      id\n      attributes {\n        Slug\n        Title\n        Tagline\n        Published\n        Author{\n          data{\n            attributes{\n              username\n            }\n          }\n        }\n        Cover {\n          img {\n            data {\n              attributes {\n                url\n                hash\n              }\n            }\n          }\n        }\n      }\n    }\n  }\n  }\n': RecentArticlesFragmentFragmentDoc,
    "\n  fragment NavigationFragment on Query {\n    navLink {\n      data {\n        attributes {\n          Link {\n            id\n            Name\n            URL\n          }\n        }\n      }\n    }\n  }\n": NavigationFragmentFragmentDoc,
    "\n  fragment NewNavigationFragment on Query {\n    navLink {\n      data {\n        attributes {\n          Link {\n            id\n            Name\n            URL\n          }\n        }\n      }\n    }\n  }\n": NewNavigationFragmentFragmentDoc,
    "\n  fragment ContactFragment on Resume {\n    Address\n    Phone\n  }\n": ContactFragmentFragmentDoc,
    "\n  fragment EducationFragment on Resume {\n    Education\n  }\n": EducationFragmentFragmentDoc,
    "\n  fragment HobbiesFragment on Resume {\n    Hobbies\n  }\n": HobbiesFragmentFragmentDoc,
    "\n  fragment HighlightImgFragment on Resume {\n    Img {\n      img {\n        data {\n          id\n          attributes {\n            url\n            hash\n          }\n        }\n      }\n    }\n  }\n": HighlightImgFragmentFragmentDoc,
    "\n  fragment ResumeEmailFragment on Resume {\n    email\n  }\n": ResumeEmailFragmentFragmentDoc,
    "\n  fragment SkillsFragment on Resume {\n    Skills\n  }\n": SkillsFragmentFragmentDoc,
    "\n  fragment WorkExpFragment on Resume {\n    Experience\n  }\n": WorkExpFragmentFragmentDoc,
    "\n  query GetAboutPage {\n    ...NavigationFragment\n    ...AboutCardFragment\n  }\n": GetAboutPageDocument,
    "\n  query GetAlbumPage {\n    ...NavigationFragment\n    ...AlbumFragment\n  }\n": GetAlbumPageDocument,
    "\n  query GetArticles($start: Int!) {\n    ...NavigationFragment\n    ...ArticleListFragment\n    ...SidebarArticlesFragment\n  }\n": GetArticlesDocument,
    "\nquery Articles {\n  articles {\n    data {\n      id\n      attributes {\n        Slug\n      }\n    }\n  }\n}\n": ArticlesDocument,
    "\n  query Article($slug: String) {\n    ...NavigationFragment\n    articles(filters: { Slug: { eq: $slug } }) {\n      data {\n        id\n        attributes {\n          Slug\n          Title\n          Tagline\n          Published\n          Content\n          Author {\n            data {\n              attributes {\n                username\n              }\n            }\n          }\n          Cover {\n            img {\n              data {\n                attributes {\n                  url\n                  hash\n                }\n              }\n            }\n          }\n        }\n      }\n    }\n    ...SidebarArticlesFragment\n  }\n": ArticleDocument,
    "\n  query GetContactPage {\n    ...NavigationFragment\n  }\n": GetContactPageDocument,
    "\n  query GetHomePage {\n    ...NavigationFragment\n    ...HeroFragment\n    ...BiographyFragment\n    ...RecentArticlesFragment\n    ...RecentAlbumsFragment\n  }\n": GetHomePageDocument,
    "\n  query GetResumeQuery {\n    resume {\n      data {\n        id\n        attributes {\n          ...ContactFragment\n          ...WorkExpFragment\n          ...EducationFragment\n          ...SkillsFragment\n          ...HighlightImgFragment\n          ...HobbiesFragment\n          ...ResumeEmailFragment\n        }\n      }\n    }\n  }\n": GetResumeQueryDocument
};
function gql(source) {
    return documents[source] ?? {};
}

;// CONCATENATED MODULE: ./gql/index.ts



/***/ })

};
;