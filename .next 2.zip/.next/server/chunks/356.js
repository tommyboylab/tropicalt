"use strict";
exports.id = 356;
exports.ids = [356];
exports.modules = {

/***/ 4405:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_future_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1608);
/* harmony import */ var next_future_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_future_image__WEBPACK_IMPORTED_MODULE_2__);



const ImgComp = (Img)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_future_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        style: {
            backgroundImage: `url(https://api.tropicalt.ca${Img.placeholder})`
        },
        id: Img.id,
        className: Img.class,
        src: `https://api.tropicalt.ca${String(Img.url)}`,
        loading: "lazy",
        alt: Img.alt,
        sizes: "100%",
        width: 2500,
        height: 2500
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImgComp);


/***/ }),

/***/ 5639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ ssrCacheExchange),
/* harmony export */   "L": () => (/* binding */ client)
/* harmony export */ });
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_0__);

const serverSide = "undefined" === "undefined";
const ssrCacheExchange = (0,urql__WEBPACK_IMPORTED_MODULE_0__.ssrExchange)({
    isClient: !serverSide
});
const client = (0,urql__WEBPACK_IMPORTED_MODULE_0__.createClient)({
    url: String("https://api.tropicalt.ca/graphql"),
    exchanges: [
        urql__WEBPACK_IMPORTED_MODULE_0__.dedupExchange,
        urql__WEBPACK_IMPORTED_MODULE_0__.cacheExchange,
        ssrCacheExchange,
        urql__WEBPACK_IMPORTED_MODULE_0__.fetchExchange
    ],
    fetchOptions: ()=>{
        return {
            headers: {}
        };
    }
});



/***/ })

};
;