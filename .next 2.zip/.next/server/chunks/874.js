exports.id = 874;
exports.ids = [874];
exports.modules = {

/***/ 4250:
/***/ ((module) => {

// Exports
module.exports = {
	"postAbout": "AboutMe_postAbout__TDPfH"
};


/***/ }),

/***/ 7595:
/***/ ((module) => {

// Exports
module.exports = {
	"blogSidebar": "Sidebar_blogSidebar__upkCA"
};


/***/ }),

/***/ 5874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Sidebar)
});

// UNUSED EXPORTS: SidebarArticlesFragment

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./gql/index.ts + 2 modules
var gql = __webpack_require__(1265);
// EXTERNAL MODULE: ./components/Home/Recents/Recents.tsx
var Recents = __webpack_require__(9177);
// EXTERNAL MODULE: ./components/Other/Avatar/Avatar.tsx
var Avatar = __webpack_require__(9011);
// EXTERNAL MODULE: ./components/Blog/Post/About/AboutMe.module.scss
var AboutMe_module = __webpack_require__(4250);
var AboutMe_module_default = /*#__PURE__*/__webpack_require__.n(AboutMe_module);
;// CONCATENATED MODULE: ./components/Blog/Post/About/AboutMe.tsx




const About = ({ img  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (AboutMe_module_default()).postAbout,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Avatar/* default */.Z, {
                img: img
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                children: `I'm just a simple man with a dream of building a personal website.`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "/about",
                children: "Read More..."
            })
        ]
    });
About.displayName = "About";
/* harmony default export */ const AboutMe = (About);

// EXTERNAL MODULE: ./components/Blog/Post/Sidebar/Sidebar.module.scss
var Sidebar_module = __webpack_require__(7595);
var Sidebar_module_default = /*#__PURE__*/__webpack_require__.n(Sidebar_module);
;// CONCATENATED MODULE: ./components/Blog/Post/Sidebar/Sidebar.tsx






const SidebarArticlesFragment = (0,gql/* gql */.P)(`
 fragment SidebarArticlesFragment on Query {
  sidebar: articles(sort: "Published:desc", pagination: { limit: 4 }) {
    data {
      id
      attributes {
        Slug
        Title
        Tagline
        Published
        Author {
          data {
            attributes {
              username
              Img {
                img {
                  data {
                    id
                    attributes {
                      url
                      hash
                    }
                  }
                }
              }
            }
          }
        }
        Cover {
          img {
            data {
              id
              attributes {
                url
                hash
              }
            }
          }
        }
      }
    }
  }
}
`);
const PostSidebar = ({ sidebar  })=>{
    const sidebarData = sidebar?.data;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Sidebar_module_default()).blogSidebar,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                children: "ˇˇˇ"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(AboutMe, {
                img: sidebar?.data?.[0]?.attributes?.Author?.data?.attributes?.Img?.img
            }),
            sidebarData && sidebarData.map((article)=>/*#__PURE__*/ jsx_runtime_.jsx(Recents/* default */.Z, {
                    id: String(article?.id),
                    type: "blog",
                    slug: String(article?.attributes?.Slug),
                    cover: `/uploads/sqip_${String(article?.attributes?.Cover?.img?.data?.attributes?.hash)}.svg`,
                    img: article?.attributes?.Cover?.img?.data?.attributes?.url,
                    title: article?.attributes?.Title,
                    date: String(article?.attributes?.Published),
                    name: article?.attributes?.Author?.data?.attributes?.username,
                    excerpt: String(article?.attributes?.Tagline)
                }, article?.id))
        ]
    });
};
PostSidebar.displayName = "Sidebar";
PostSidebar.fragments = {
    SidebarArticlesFragment
};
/* harmony default export */ const Sidebar = (PostSidebar);


/***/ })

};
;