"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ ssrCacheExchange),
/* harmony export */   "L": () => (/* binding */ client)
/* harmony export */ });
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_0__);

const serverSide = "undefined" === "undefined";
const ssrCacheExchange = (0,urql__WEBPACK_IMPORTED_MODULE_0__.ssrExchange)({
    isClient: !serverSide
});
const client = (0,urql__WEBPACK_IMPORTED_MODULE_0__.createClient)({
    url: String("https://api.tropicalt.ca/graphql"),
    exchanges: [
        urql__WEBPACK_IMPORTED_MODULE_0__.dedupExchange,
        urql__WEBPACK_IMPORTED_MODULE_0__.cacheExchange,
        ssrCacheExchange,
        urql__WEBPACK_IMPORTED_MODULE_0__.fetchExchange
    ],
    fetchOptions: ()=>{
        return {
            headers: {}
        };
    }
});



/***/ }),

/***/ 5656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _gql_urqlClient__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5639);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);





const globalStyle = {
    __html: `
  
  /*
  1. Use a more-intuitive box-sizing model.
*/
*, *::before, *::after {
  box-sizing: border-box;
}
/*
  2. Remove default margin
*/
* {
  margin: 0;
}
/*
  3. Allow percentage-based heights in the application
*/
html, body {
  height: 100%;
}
/*
  Typographic tweaks!
  4. Add accessible line-height
  5. Improve text rendering
*/
body {
  line-height: 1.5;
  -webkit-font-smoothing: antialiased;
}
/*
  6. Improve media defaults
*/
img, picture, video, canvas, svg {
  display: block;
  max-width: 100%;
}
/*
  7. Remove built-in form typography styles
*/
input, button, textarea, select {
  font: inherit;
}
/*
  8. Avoid text overflows
*/
p, h1, h2, h3, h4, h5, h6 {
  overflow-wrap: break-word;
}
/*
  9. Create a root stacking context
*/
#root, #__next {
  isolation: isolate;
}

  *,
  *::before,
  *::after {
    padding: 0;
    margin: 0;
    font-family: Didact Gothic;
    font-size:1.15rem;
    line-height:1.5em;
    box-sizing: border-box;
    -webkit-tap-highlight-color: transparent;
  }

  h1 {
   font-family: Raleway;
  }

  /* didact-gothic-regular - latin */
  @font-face {
    font-family: 'Didact Gothic';
    font-style: normal;
    font-weight: 400;
    font-display: swap;
    src: url(/static/fonts/DidactGothic/didact-gothic-v13-latin-regular.eot'); /* IE9 Compat Modes */
    src: local('Didact Gothic Regular'), local('DidactGothic-Regular'),
       url('/static/fonts/DidactGothic/didact-gothic-v13-latin-regular.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
       url('/static/fonts/DidactGothic/didact-gothic-v13-latin-regular.woff2') format('woff2'), /* Super Modern Browsers */
       url('/static/fonts/DidactGothic/didact-gothic-v13-latin-regular.woff') format('woff'), /* Modern Browsers */
       url('/static/fonts/DidactGothic/didact-gothic-v13-latin-regular.ttf') format('truetype'), /* Safari, Android, iOS */
       url('/static/fonts//DidactGothicdidact-gothic-v13-latin-regular.svg#DidactGothic') format('svg'); /* Legacy iOS */
  }
  
 /* raleway-regular - latin */
  @font-face {
    font-family: 'Raleway';
    font-style: normal;
    font-weight: 400;
    font-display: swap;
    src: url('/static/fonts/Raleway/raleway-v14-latin-regular.eot'); /* IE9 Compat Modes */
    src: local('Raleway'), local('Raleway-Regular'),
       url('/static/fonts/Raleway/raleway-v14-latin-regular.eot?#iefix') format('embedded-opentype'), /* IE6-IE8 */
       url('/static/fonts/Raleway/raleway-v14-latin-regular.woff2') format('woff2'), /* Super Modern Browsers */
       url('/static/fonts/Raleway/raleway-v14-latin-regular.woff') format('woff'), /* Modern Browsers */
       url('/static/fonts/Raleway/raleway-v14-latin-regular.ttf') format('truetype'), /* Safari, Android, iOS */
       url('/static/fonts/Raleway/raleway-v14-latin-regular.svg#Raleway') format('svg'); /* Legacy iOS */
  }
  
  ::selection {
    color:Jade;
    background: Violet; /* WebKit/Blink Browsers */
  }
  ::-moz-selection {
    color:Jade;
    background: Violet; /* Gecko Browsers */
  }
  ::placeholder{ /* Chrome, Firefox, Opera, Safari 10.1+ */
    color: rgb(0, 255, 136);
  }
  ::-ms-input-placeholder {
    color: rgb(0, 255, 136);
  }

/* Change Autocomplete styles in Chrome*/
  input:-webkit-autofill,
  input:-webkit-autofill:hover, 
  input:-webkit-autofill:focus,
  textarea:-webkit-autofill,
  textarea:-webkit-autofill:hover,
  textarea:-webkit-autofill:focus,
  select:-webkit-autofill,
  select:-webkit-autofill:hover,
  select:-webkit-autofill:focus {
  border-bottom: 2px solid #be37fa;
  -webkit-text-fill-color: #be37fa;
  -webkit-box-shadow: 0 0 0 500em inset #00ffaa;
  }

  html {
    background-color: rgb(30,30,40);
    width:100%;
    height:100%;
  }
  
  button:focus {
  outline:0;
  box-shadow: 0 0 .5em rgba(90, 225, 125, 1);
  }
`
};
const TropicalT = ({ Component , pageProps , router  })=>{
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const { urqlState  } = pageProps;
    if (urqlState) {
        _gql_urqlClient__WEBPACK_IMPORTED_MODULE_3__/* .ssrCacheExchange.restoreData */ .I.restoreData(urqlState);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_4___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("style", {
                        dangerouslySetInnerHTML: globalStyle
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(urql__WEBPACK_IMPORTED_MODULE_2__.Provider, {
                value: _gql_urqlClient__WEBPACK_IMPORTED_MODULE_3__/* .client */ .L,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                    ...pageProps,
                    router: router
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TropicalT);


/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2977:
/***/ ((module) => {

module.exports = require("urql");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5656));
module.exports = __webpack_exports__;

})();