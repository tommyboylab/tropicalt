(() => {
var exports = {};
exports.id = 521;
exports.ids = [521];
exports.modules = {

/***/ 9280:
/***/ ((module) => {

// Exports
module.exports = {
	"aboutCardImg": "AboutCards_aboutCardImg__QNGWc",
	"aboutCardText": "AboutCards_aboutCardText__0JmDD"
};


/***/ }),

/***/ 3481:
/***/ ((module) => {

// Exports
module.exports = {
	"layout": "About_layout__0H7sZ"
};


/***/ }),

/***/ 8809:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ About),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./gql/index.ts + 2 modules
var gql = __webpack_require__(1265);
// EXTERNAL MODULE: ./components/About/AboutCards.module.scss
var AboutCards_module = __webpack_require__(9280);
var AboutCards_module_default = /*#__PURE__*/__webpack_require__.n(AboutCards_module);
;// CONCATENATED MODULE: ./components/About/AboutCard/AboutCardText.tsx



const Text = (Txt)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (AboutCards_module_default()).aboutCardText,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                children: Txt.title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                children: Txt.excerpt
            })
        ]
    });
/* harmony default export */ const AboutCardText = (Text);

// EXTERNAL MODULE: ./components/Other/Img/Img.tsx
var Img = __webpack_require__(4405);
;// CONCATENATED MODULE: ./components/About/AboutCards.tsx






const AboutCardFragment = (0,gql/* gql */.P)(`
  fragment AboutCardFragment on Query {
  about {
    data {
      attributes {
        AboutCard {
          id
          Tagline
          Extension
          Img {
            img {
              data {
                attributes {
                  url
                  hash
                }
              }
            }
          }
        }
      }
    }
  }
  }
`);
const AboutCards = ({ about  })=>{
    const aboutData = about?.data?.attributes?.AboutCard;
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: aboutData?.map((aboutCard)=>{
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Img/* default */.Z, {
                        class: (AboutCards_module_default()).aboutCardImg,
                        url: String(aboutCard?.Img?.[0]?.img?.data?.attributes?.url),
                        placeholder: `/uploads/sqip_${String(aboutCard?.Img?.[0]?.img?.data?.attributes?.hash)}.svg`,
                        alt: `Image for ${String(aboutCard?.Tagline)}`
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AboutCardText, {
                        title: String(aboutCard?.Tagline),
                        excerpt: String(aboutCard?.Extension)
                    })
                ]
            }, aboutCard?.id);
        })
    });
};
AboutCards.displayName = "AboutCards";
AboutCards.fragments = {
    AboutCardFragment
};
/* harmony default export */ const About_AboutCards = (AboutCards);

// EXTERNAL MODULE: ./components/Other/Layout/About.module.scss
var About_module = __webpack_require__(3481);
var About_module_default = /*#__PURE__*/__webpack_require__.n(About_module);
// EXTERNAL MODULE: ./components/Other/Meta/Meta.tsx
var Meta = __webpack_require__(4617);
// EXTERNAL MODULE: external "urql"
var external_urql_ = __webpack_require__(2977);
// EXTERNAL MODULE: ./components/Other/Load/Load.tsx
var Load = __webpack_require__(2151);
// EXTERNAL MODULE: ./components/Other/Error/Error.tsx
var Error = __webpack_require__(7874);
// EXTERNAL MODULE: ./gql/urqlClient.ts
var urqlClient = __webpack_require__(5639);
// EXTERNAL MODULE: ./components/Nav/NewNav.tsx
var NewNav = __webpack_require__(8355);
;// CONCATENATED MODULE: ./pages/about.tsx











const GetAboutCardQuery = (0,gql/* gql */.P)(`
  query GetAboutPage {
    ...NavigationFragment
    ...AboutCardFragment
  }
`);
function About() {
    const [result] = (0,external_urql_.useQuery)({
        query: GetAboutCardQuery
    });
    const { data , fetching , error  } = result;
    if (fetching && !data) return /*#__PURE__*/ jsx_runtime_.jsx(Load/* default */.Z, {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx(Error/* default */.Z, {});
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: (About_module_default()).layout,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Meta/* default */.Z, {
                title: "T^T - About Me",
                excerpt: data?.about?.data?.attributes?.AboutCard?.[0]?.Extension,
                imgUrl: data?.about?.data?.attributes?.AboutCard?.[0]?.Img?.[0]?.img?.data?.attributes?.url,
                url: "/about"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NewNav/* default */.Z, {
                navLink: data?.navLink
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(About_AboutCards, {
                about: data?.about
            })
        ]
    });
};
async function getStaticProps() {
    await urqlClient/* client.query */.L.query(GetAboutCardQuery).toPromise();
    return {
        props: {
            urqlState: urqlClient/* ssrCacheExchange.extractData */.I.extractData()
        },
        revalidate: 1200
    };
}


/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2977:
/***/ ((module) => {

"use strict";
module.exports = require("urql");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,608,30,356,355], () => (__webpack_exec__(8809)));
module.exports = __webpack_exports__;

})();