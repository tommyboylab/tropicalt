(() => {
var exports = {};
exports.id = 10;
exports.ids = [10];
exports.modules = {

/***/ 925:
/***/ ((module) => {

// Exports
module.exports = {
	"albumList": "Gallery_albumList__pnV8I"
};


/***/ }),

/***/ 9888:
/***/ ((module) => {

// Exports
module.exports = {
	"nav": "Nav_nav__qW6YP",
	"menu": "Nav_menu__KjuDk"
};


/***/ }),

/***/ 7891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ albums_Albums),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/Home/Recents/Recents.tsx
var Recents = __webpack_require__(9177);
// EXTERNAL MODULE: ./components/Gallery/Gallery.module.scss
var Gallery_module = __webpack_require__(925);
var Gallery_module_default = /*#__PURE__*/__webpack_require__.n(Gallery_module);
// EXTERNAL MODULE: ./gql/index.ts + 2 modules
var gql = __webpack_require__(1265);
;// CONCATENATED MODULE: ./components/Gallery/Gallery.tsx





const AlbumFragment = (0,gql/* gql */.P)(`
  fragment AlbumFragment on Query {
    albums(sort: "Date:desc") {
      data {
      id
        attributes {
          Name
          Tagline
          Slug
          Date
          Location
          Photographer {
            data {
              attributes {
                username
              }
            }
          }
          Cover {
            img {
              data {
                attributes {
                  url
                  hash
                }
              }
            }
          }
          GPhotoId
        }
      }
    }
  }
`);
const Albums = ({ albums  })=>{
    const albumData = albums?.data;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (Gallery_module_default()).albumList,
        children: albumData && albumData.map((album)=>/*#__PURE__*/ jsx_runtime_.jsx(Recents/* default */.Z, {
                type: "albums",
                id: String(album?.id),
                slug: String(album?.attributes?.Slug),
                cover: `/uploads/sqip_${String(album?.attributes?.Cover?.img?.data?.attributes?.hash)}.svg`,
                img: album?.attributes?.Cover?.img?.data?.attributes?.url,
                title: String(album?.attributes?.Name),
                date: String(album?.attributes?.Date),
                name: album?.attributes?.Photographer?.data?.attributes?.username,
                excerpt: `Location: ${String(album?.attributes?.Location)}`
            }, album.id))
    });
};
Albums.displayName = "Album Gallery";
Albums.fragments = {
    AlbumFragment: AlbumFragment
};
/* harmony default export */ const Gallery = (Albums);

// EXTERNAL MODULE: external "next/dist/shared/lib/styled-jsx"
var styled_jsx_ = __webpack_require__(7561);
var styled_jsx_default = /*#__PURE__*/__webpack_require__.n(styled_jsx_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Nav/ActiveLink/ActiveLink.tsx




const ActiveLink = ({ children , router , href  })=>{
    // const handleClick: MouseEventHandler = useCallback(
    //   (e) => {
    //     e.preventDefault();
    //     void router.push(href).then(() => window.scrollTo(0, 0));
    //   },
    //   [href, router]
    // );
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        className: router.pathname == href ? "active" : "",
        href: href,
        children: children
    });
};
/* harmony default export */ const ActiveLink_ActiveLink = ((0,router_.withRouter)(ActiveLink));

// EXTERNAL MODULE: ./components/Nav/Nav.module.scss
var Nav_module = __webpack_require__(9888);
var Nav_module_default = /*#__PURE__*/__webpack_require__.n(Nav_module);
;// CONCATENATED MODULE: ./components/Nav/Nav.tsx






const NavigationFragment = (0,gql/* gql */.P)(`
  fragment NavigationFragment on Query {
    navLink {
      data {
        attributes {
          Link {
            id
            Name
            URL
          }
        }
      }
    }
  }
`);
const Nav = ({ navLink  })=>{
    const navData = navLink?.data?.attributes?.Link;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: (Nav_module_default()).nav,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: (Nav_module_default()).menu,
                children: "T^T"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "jsx-6e707751f048124f",
                children: [
                    jsx_runtime_.jsx((styled_jsx_default()), {
                        id: "6e707751f048124f",
                        children: '.link.active.jsx-6e707751f048124f:after{height:-.2em;text-align:center;content:" -------"}'
                    }),
                    navData && navData.map((nav)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx(ActiveLink_ActiveLink, {
                            href: String(nav?.URL),
                            children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "jsx-6e707751f048124f" + " " + "link",
                                children: nav?.Name
                            })
                        }, nav?.id);
                    })
                ]
            })
        ]
    });
};
Nav.displayName = "Nav";
Nav.fragments = {
    NavigationFragment
};
/* harmony default export */ const Nav_Nav = (Nav);

// EXTERNAL MODULE: ./components/Other/Meta/Meta.tsx
var Meta = __webpack_require__(4617);
// EXTERNAL MODULE: external "urql"
var external_urql_ = __webpack_require__(2977);
// EXTERNAL MODULE: ./components/Other/Load/Load.tsx
var Load = __webpack_require__(2151);
// EXTERNAL MODULE: ./components/Other/Error/Error.tsx
var Error = __webpack_require__(7874);
// EXTERNAL MODULE: ./gql/urqlClient.ts
var urqlClient = __webpack_require__(5639);
;// CONCATENATED MODULE: ./pages/albums.tsx










const GetGalleryQuery = (0,gql/* gql */.P)(`
  query GetAlbumPage {
    ...NavigationFragment
    ...AlbumFragment
  }
`);
function albums_Albums() {
    const [result] = (0,external_urql_.useQuery)({
        query: GetGalleryQuery
    });
    const { data , fetching , error  } = result;
    if (fetching && !data) return /*#__PURE__*/ jsx_runtime_.jsx(Load/* default */.Z, {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx(Error/* default */.Z, {});
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Meta/* default */.Z, {
                title: "T^T - Gallery",
                excerpt: "My life through pictures ",
                imgUrl: data?.albums?.data?.[0]?.attributes?.Cover?.img?.data?.attributes?.url,
                url: "/albums"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Nav_Nav, {
                navLink: data?.navLink
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Gallery, {
                albums: data?.albums
            })
        ]
    });
};
async function getStaticProps() {
    await urqlClient/* client.query */.L.query(GetGalleryQuery).toPromise();
    return {
        props: {
            urqlState: urqlClient/* ssrCacheExchange.extractData */.I.extractData()
        },
        revalidate: 1200
    };
}


/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7561:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/styled-jsx");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 661:
/***/ ((module) => {

"use strict";
module.exports = require("react-moment");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2977:
/***/ ((module) => {

"use strict";
module.exports = require("urql");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,608,30,356,177], () => (__webpack_exec__(7891)));
module.exports = __webpack_exports__;

})();