(() => {
var exports = {};
exports.id = 195;
exports.ids = [195];
exports.modules = {

/***/ 4082:
/***/ ((module) => {

// Exports
module.exports = {
	"postHeader": "Header_postHeader__Q2J3Q"
};


/***/ }),

/***/ 7630:
/***/ ((module) => {

// Exports
module.exports = {
	"postList": "List_postList__Lm07B",
	"postControls": "List_postControls__FJ__F"
};


/***/ }),

/***/ 3661:
/***/ ((module) => {

// Exports
module.exports = {
	"layout": "Blog_layout__dr8de",
	"postControls": "Blog_postControls__0FwIk"
};


/***/ }),

/***/ 8799:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "GetArticlesQuery": () => (/* binding */ GetArticlesQuery),
  "default": () => (/* binding */ Blog),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/Nav/Footer.tsx
var Footer = __webpack_require__(1783);
// EXTERNAL MODULE: ./components/Blog/Header/Header.module.scss
var Header_module = __webpack_require__(4082);
var Header_module_default = /*#__PURE__*/__webpack_require__.n(Header_module);
;// CONCATENATED MODULE: ./components/Blog/Header/Header.tsx



const Header = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Header_module_default()).postHeader,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                children: "Teatime"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                children: "The blog that involves me, drinking a pot of tea and sharing some thoughts."
            })
        ]
    });
/* harmony default export */ const Header_Header = (Header);

// EXTERNAL MODULE: ./components/Blog/Post/Sidebar/Sidebar.tsx + 1 modules
var Sidebar = __webpack_require__(5874);
// EXTERNAL MODULE: ./gql/index.ts + 2 modules
var gql = __webpack_require__(1265);
// EXTERNAL MODULE: ./components/Home/Recents/Recents.tsx
var Recents = __webpack_require__(9177);
// EXTERNAL MODULE: ./components/Blog/List.module.scss
var List_module = __webpack_require__(7630);
var List_module_default = /*#__PURE__*/__webpack_require__.n(List_module);
;// CONCATENATED MODULE: ./components/Blog/List.tsx





const ArticleListFragment = (0,gql/* gql */.P)(`
  fragment ArticleListFragment on Query {
    list: articles(sort: "Published:desc", pagination: { start: $start, limit: 7 }) {
      data {
        id
        attributes {
          Slug
          Title
          Tagline
          Published
          Author {
            data {
              attributes {
                username
              }
            }
          }
          Cover {
            img {
              data {
                attributes {
                  url
                  hash
                }
              }
            }
          }
        }
      }
    }
  }
`);
const Articles = ({ list  })=>{
    const listData = list?.data;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (List_module_default()).postList,
        children: listData && listData.map((article)=>/*#__PURE__*/ jsx_runtime_.jsx(Recents/* default */.Z, {
                id: String(article?.id),
                type: "blog",
                slug: String(article?.attributes?.Slug),
                cover: `/uploads/sqip_${String(article?.attributes?.Cover?.img?.data?.attributes?.hash)}.svg`,
                img: article?.attributes?.Cover?.img?.data?.attributes?.url,
                title: article?.attributes?.Title,
                date: String(article?.attributes?.Published),
                name: article?.attributes?.Author?.data?.attributes?.username,
                excerpt: String(article?.attributes?.Tagline)
            }, article?.id))
    });
};
Articles.displayName = "ArticleList";
Articles.fragments = {
    ArticleListFragment
};
/* harmony default export */ const List = (Articles);

// EXTERNAL MODULE: ./components/Other/Layout/Blog.module.scss
var Blog_module = __webpack_require__(3661);
var Blog_module_default = /*#__PURE__*/__webpack_require__.n(Blog_module);
// EXTERNAL MODULE: ./components/Other/Meta/Meta.tsx
var Meta = __webpack_require__(4617);
// EXTERNAL MODULE: external "urql"
var external_urql_ = __webpack_require__(2977);
// EXTERNAL MODULE: ./components/Other/Load/Load.tsx
var Load = __webpack_require__(2151);
// EXTERNAL MODULE: ./components/Other/Error/Error.tsx
var Error = __webpack_require__(7874);
// EXTERNAL MODULE: ./gql/urqlClient.ts
var urqlClient = __webpack_require__(5639);
// EXTERNAL MODULE: ./components/Nav/NewNav.tsx
var NewNav = __webpack_require__(8355);
;// CONCATENATED MODULE: ./pages/blog.tsx














const GetArticlesQuery = (0,gql/* gql */.P)(`
  query GetArticles($start: Int!) {
    ...NavigationFragment
    ...ArticleListFragment
    ...SidebarArticlesFragment
  }
`);
function Blog() {
    const { 0: nextPosts , 1: setNextPosts  } = (0,external_react_.useState)(0);
    const prev = (0,external_react_.useCallback)(()=>{
        setNextPosts(nextPosts - 7), window.scrollTo(0, 0);
    }, [
        nextPosts
    ]);
    const next = (0,external_react_.useCallback)(()=>{
        setNextPosts(nextPosts + 7), window.scrollTo(0, 0);
    }, [
        nextPosts
    ]);
    const [result] = (0,external_urql_.useQuery)({
        query: GetArticlesQuery,
        variables: {
            start: nextPosts
        }
    });
    const { data , fetching , error  } = result;
    if (fetching && !data) return /*#__PURE__*/ jsx_runtime_.jsx(Load/* default */.Z, {});
    if (error) return /*#__PURE__*/ jsx_runtime_.jsx(Error/* default */.Z, {});
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
        className: (Blog_module_default()).layout,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Meta/* default */.Z, {
                title: "T^T - Blog",
                excerpt: "The blog that involves me, drinking a pot of tea and sharing some thoughts.",
                imgUrl: data?.list?.data?.[0]?.attributes?.Cover?.img?.data?.attributes?.url,
                url: "/blog"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NewNav/* default */.Z, {
                navLink: data?.navLink
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Header_Header, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(List, {
                list: data?.list
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Blog_module_default()).postControls,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: prev,
                        disabled: nextPosts === 0,
                        children: "Prev"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: next,
                        disabled: data?.list?.data ? data?.list?.data?.length < 7 : true,
                        children: "Next"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Sidebar/* default */.Z, {
                sidebar: data?.sidebar
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
        ]
    });
};
async function getStaticProps() {
    await urqlClient/* client.query */.L.query(GetArticlesQuery, {
        start: 1
    }).toPromise();
    return {
        props: {
            urqlState: urqlClient/* ssrCacheExchange.extractData */.I.extractData()
        },
        revalidate: 1200
    };
}


/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 661:
/***/ ((module) => {

"use strict";
module.exports = require("react-moment");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2977:
/***/ ((module) => {

"use strict";
module.exports = require("urql");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,608,30,356,355,177,115,874], () => (__webpack_exec__(8799)));
module.exports = __webpack_exports__;

})();