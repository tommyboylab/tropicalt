(() => {
var exports = {};
exports.id = 492;
exports.ids = [492];
exports.modules = {

/***/ 8960:
/***/ ((module) => {

// Exports
module.exports = {
	"postText": "Body_postText__WjNVg"
};


/***/ }),

/***/ 2124:
/***/ ((module) => {

// Exports
module.exports = {
	"commentList": "Comments_commentList__n9sIR",
	"commentHeader": "Comments_commentHeader__CNotC",
	"commentAvatar": "Comments_commentAvatar__6dsbH",
	"commentForm": "Comments_commentForm__wSZmm",
	"formInput": "Comments_formInput__HgZOR",
	"formButton": "Comments_formButton__vogqs",
	"comment": "Comments_comment__hQYCh",
	"commentName": "Comments_commentName__DL9xF",
	"commentContent": "Comments_commentContent__9ilB_",
	"commentNested": "Comments_commentNested__xMCMY",
	"commentRating": "Comments_commentRating__mEpli",
	"commentReply": "Comments_commentReply__SIUS1",
	"commentLikeImg": "Comments_commentLikeImg__6JI0v",
	"commentDislikeImg": "Comments_commentDislikeImg__molnX",
	"commentLike": "Comments_commentLike__H1srC",
	"commentDislike": "Comments_commentDislike__ZIWBb",
	"commentViewMore": "Comments_commentViewMore__CgXQk",
	"submitError": "Comments_submitError__qYbgz"
};


/***/ }),

/***/ 5181:
/***/ ((module) => {

// Exports
module.exports = {
	"postImg": "CoverImg_postImg__FoZRl"
};


/***/ }),

/***/ 5987:
/***/ ((module) => {

// Exports
module.exports = {
	"mobileHeader": "MobileHeader_mobileHeader__e9Um7"
};


/***/ }),

/***/ 4067:
/***/ ((module) => {

// Exports
module.exports = {
	"layout": "Post_layout__KPIeH"
};


/***/ }),

/***/ 8357:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3135);
/* harmony import */ var _Body_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8960);
/* harmony import */ var _Body_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Body_module_scss__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_markdown__WEBPACK_IMPORTED_MODULE_2__]);
react_markdown__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const Body = ({ content  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_Body_module_scss__WEBPACK_IMPORTED_MODULE_3___default().postText),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_2__["default"], {
            children: content
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Body);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6613:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3135);
/* harmony import */ var _Rating_Rating__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1123);
/* harmony import */ var _CommentForm_CommentForm__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5682);
/* harmony import */ var _Comments_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2124);
/* harmony import */ var _Comments_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_Comments_module_scss__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_markdown__WEBPACK_IMPORTED_MODULE_2__, _CommentForm_CommentForm__WEBPACK_IMPORTED_MODULE_4__]);
([react_markdown__WEBPACK_IMPORTED_MODULE_2__, _CommentForm_CommentForm__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const Comment = ({ comment , commentId , userId , nested , articleId  })=>{
    const { 0: openReplyBox , 1: setOpenReplyBox  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const openReply = ()=>{
        setOpenReplyBox(!openReplyBox);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_5___default().comment),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: String(comment?.Author?.data?.attributes?.Img?.img?.data?.attributes?.url),
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_5___default().commentAvatar),
                alt: `${String(comment?.Author?.data?.attributes?.username)}'s avatar image`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_5___default().commentName),
                children: comment?.Author?.data?.attributes?.username
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_2__["default"], {
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_5___default().commentContent),
                children: String(comment?.Content)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Rating_Rating__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                commentId: commentId,
                likes: comment?.Likes,
                dislikes: comment?.Dislikes,
                userId: userId,
                replyIsOpen: openReplyBox,
                nested: nested,
                reply: openReply
            }),
            openReplyBox && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CommentForm_CommentForm__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                commentId: commentId,
                nested: nested,
                userId: userId,
                articleId: String(articleId)
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Comment);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1123:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Comments_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2124);
/* harmony import */ var _Comments_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Comments_module_scss__WEBPACK_IMPORTED_MODULE_3__);





// import { Comment } from '../Comment';
const UpdateCommentLikes = (0,urql__WEBPACK_IMPORTED_MODULE_2__.gql)(`
mutation updateCommentLikes(
  $commentId: ID!
  $likes: Int!
  $dislikes: Int!
) {
  updateComment(
    id: $commentId
    data: { Likes: { UserId: $likes }, Dislikes: { UserId: $dislikes } }
  ) {
    data {
      id
      attributes {
        Likes {
          UserId
        }
        Dislikes {
          UserId
        }
      }
    }
  }
}

`);
const Rating = ({ commentId , likes , dislikes , userId , nested , reply , replyIsOpen  })=>{
    const likeNum = likes?.length;
    const dislikeNum = dislikes?.length;
    const isLiked = likes?.some((like)=>like?.UserId === userId);
    const isDisliked = dislikes?.some((dislike)=>dislike?.UserId === userId);
    const liked = ()=>isLiked ? likes?.filter((like)=>like?.UserId !== userId) : likes ? [
            ...likes,
            {
                UserId: userId
            }
        ] : likes;
    const disliked = ()=>isDisliked ? dislikes?.filter((dislike)=>dislike?.UserId !== userId) : dislikes ? [
            ...dislikes,
            {
                UserId: userId
            }
        ] : dislikes;
    //      ? [...dislikes, { id: String(dislikes?.length + 1), me }]
    const removeLike = ()=>likes?.some((like)=>like?.UserId === userId) ? likes?.filter((like)=>like?.UserId !== userId) : likes;
    const removeDislike = ()=>dislikes?.some((dislike)=>dislike?.UserId === userId) ? dislikes?.filter((dislike)=>dislike?.UserId !== userId) : dislikes;
    const [UpdateCommentLikesResult, updateCommentLikes] = (0,urql__WEBPACK_IMPORTED_MODULE_2__.useMutation)(UpdateCommentLikes);
    const [UpdateCommentDislikesResult, updateCommentDislikes] = (0,urql__WEBPACK_IMPORTED_MODULE_2__.useMutation)(UpdateCommentLikes);
    const updateLike = async (commentID)=>{
        await updateCommentLikes({
            variables: {
                commentID,
                likes: liked(),
                dislikes: removeDislike()
            }
        });
    };
    const updateDislike = async (commentID)=>{
        await updateCommentDislikes({
            variables: {
                commentID,
                likes: removeLike(),
                dislikes: disliked()
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_3___default().commentRating),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                "aria-disabled": UpdateCommentLikesResult.fetching,
                onClick: void updateLike(String(commentId)),
                style: {
                    fill: `${isLiked ? "#0FA" : "black"}`
                },
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_3___default().commentLikeImg),
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 512 512",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M452 188h-30c-7 0-13 1-19 3L305 37l-13-18-1-1a60 60 0 00-100 61v2l1 1 10 20c9 18 24 47 26 56-1 11-15 17-25 17H71a57 57 0 00-49 86 57 57 0 00-7 83l8 8a57 57 0 0022 78c-3 7-5 15-5 23 0 34 24 59 57 59h196a20 20 0 100-40H97c-15 0-17-13-17-19 0-8 7-12 9-13 11-7 13-16 13-20 0-13-11-23-25-23h-5c-9 0-17-8-17-17 0-6 3-12 9-15h1c9-5 13-12 13-21 0-7-5-20-24-21-8-1-14-8-14-17 0-8 5-15 13-16 12-4 20-13 20-24 0-5-2-13-12-20-4-3-7-8-7-14 0-9 8-17 17-17h132c30 0 64-22 65-57 0-12-9-31-30-74a2751 2751 0 01-10-24 20 20 0 0133-15l10 14 101 157c-6 9-10 20-10 32v204c0 33 27 60 60 60h30c33 0 60-27 60-60V248c0-33-27-60-60-60zm20 264c0 11-9 20-20 20h-30c-11 0-20-9-20-20V248c0-11 9-20 20-20h30c11 0 20 9 20 20v204z"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_3___default().commentLike),
                children: likeNum
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                "aria-disabled": UpdateCommentDislikesResult.fetching,
                onClick: void updateDislike(String(commentId)),
                style: {
                    fill: `${isDisliked ? "red" : "black"}`
                },
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_3___default().commentDislikeImg),
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 512 512",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M512 206a58 58 0 00-23-46 57 57 0 00-22-78c3-7 5-15 5-23 0-34-24-59-57-59H219a20 20 0 100 40h196c15 0 17 13 17 19 0 8-7 12-9 13-11 7-13 16-13 20 0 13 11 23 25 23h5c9 0 17 8 17 17 0 6-3 12-9 15h-1c-9 5-13 12-13 21 0 7 5 20 24 21 8 1 14 8 14 17 0 8-5 15-13 16-12 4-20 13-20 24 0 5 2 13 12 20 4 3 7 8 7 14 0 9-8 17-17 17H309c-30 0-64 22-65 57 0 12 9 31 30 74a2802 2802 0 0110 24 20 20 0 01-33 15l-10-14-101-157c6-9 10-20 10-32V60c0-33-27-60-60-60H60C27 0 0 27 0 60v204c0 33 27 60 60 60h30c7 0 13-1 19-3l98 154 13 18 1 1a60 60 0 00100-61v-2l-1-1-10-20c-9-18-24-47-26-56 1-11 15-17 25-17h132a57 57 0 0049-86c14-11 22-27 22-45zm-402 58c0 11-9 20-20 20H60c-11 0-20-9-20-20V60c0-11 9-20 20-20h30c11 0 20 9 20 20v204z"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_3___default().commentDislike),
                children: dislikeNum
            }),
            !nested && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_3___default().commentReply),
                style: {
                    fill: `${replyIsOpen ? "gold" : "black"}`
                },
                onClick: reply,
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 512 512",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M171 313L46 187c-8-8-8-20 0-28L171 34a20 20 0 00-28-28L18 131a60 60 0 000 84l125 126a20 20 0 0028 0c8-8 8-20 0-28z"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M332 153H119a20 20 0 100 40h213a140 140 0 010 279 20 20 0 100 40 180 180 0 000-359z"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Rating);


/***/ }),

/***/ 5682:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1908);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _app_gql__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1265);
/* harmony import */ var _Comments_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2124);
/* harmony import */ var _Comments_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_Comments_module_scss__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_3__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_2__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const getUserQuery = (0,_app_gql__WEBPACK_IMPORTED_MODULE_7__/* .gql */ .P)(`
query getUser($userId: ID!) {
  usersPermissionsUser(id: $userId) {
    data {
      attributes {
        username
        Img {
          img {
            data {
              id
              attributes {
                url
                hash
              }
            }
          }
        }
      }
    }
  }
}`);
const CreateComment = (0,_app_gql__WEBPACK_IMPORTED_MODULE_7__/* .gql */ .P)(`
  mutation AddComment($articleId: ID!, $userId: ID!, $content: String!, $date: DateTime!, $parentId: ID) {
    createComment(
      data: { article: $articleId, Author: $userId, Content: $content, Published: $date, Parent: $parentId }
    ) {
      data {
        id
        attributes {
          Content
          Author {
            data {
              id
            }
          }
          article {
            data {
              id
            }
          }
          Published
          Parent {
            data {
              id
            }
          }
        }
      }
    }
  }
`);
const commentSchema = yup__WEBPACK_IMPORTED_MODULE_4__.object({
    content: yup__WEBPACK_IMPORTED_MODULE_4__.string().min(2, `That's not good enough!`).max(40).required()
});
const CommentForm = ({ commentId , userId , articleId , nested  })=>{
    const commentCreateDate = moment__WEBPACK_IMPORTED_MODULE_5___default()().toISOString();
    const commentParentID = nested ? commentId : null;
    const [addCommentResult, addComment] = (0,urql__WEBPACK_IMPORTED_MODULE_6__.useMutation)(CreateComment);
    const [result] = (0,urql__WEBPACK_IMPORTED_MODULE_6__.useQuery)({
        query: getUserQuery,
        variables: {
            userId: String(userId)
        }
    });
    const { data , fetching , error  } = result;
    console.log(fetching);
    console.log(error);
    const userData = data?.usersPermissionsUser;
    const { register , handleSubmit , formState , reset , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
        mode: "onChange",
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_3__.yupResolver)(commentSchema)
    });
    const onSubmit = async (data)=>{
        await addComment({
            articleId: String(articleId),
            content: data.content,
            date: commentCreateDate,
            parentId: String(commentParentID),
            userId: String(userId)
        }).then((result)=>{
            if (result.error) {
                console.error("Oh no!", result.error);
            }
            return;
        });
        reset({
            content: ""
        });
    };
    console.log("Mutation is fetching", addCommentResult.fetching);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_8___default().commentForm),
        onSubmit: void handleSubmit(onSubmit),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_8___default().commentAvatar),
                src: String(userData?.data?.attributes?.Img?.img?.data?.attributes?.url),
                alt: `${String(userData?.data?.attributes?.username)}'s Avatar`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_8___default().formInput),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "text",
                    placeholder: "Leave a comment",
                    ...register("content", {
                        required: true
                    }),
                    maxLength: 40,
                    minLength: 2
                })
            }),
            errors.content && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_8___default().error),
                children: errors.content.message
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_8___default().formButton),
                type: "submit",
                onClick: ()=>{
                    handleSubmit(onSubmit);
                },
                disabled: !!addCommentResult.error || !formState.isValid || errors && addCommentResult.fetching,
                children: addCommentResult.error ? `Error :( Please try again` : `Send`
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CommentForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8613:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Comments_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2124);
/* harmony import */ var _Comments_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_Comments_module_scss__WEBPACK_IMPORTED_MODULE_2__);



const CommentHeader = ({ totalComments  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_2___default().commentHeader),
        children: totalComments > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    children: "Comments:"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                    children: [
                        totalComments,
                        " ",
                        totalComments > 1 ? "Comments" : "Comment"
                    ]
                })
            ]
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
            children: "Leave a comment below"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CommentHeader);


/***/ }),

/***/ 8901:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export GetCommentList */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _app_gql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1265);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Comments_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2124);
/* harmony import */ var _Comments_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_Comments_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _CommentHeader_CommentHeader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8613);
/* harmony import */ var _CommentForm_CommentForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5682);
/* harmony import */ var _Comment_Comment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6613);
/* harmony import */ var _NestedComment_NestedComment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4997);
/* harmony import */ var _Other_Load_Load__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2151);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CommentForm_CommentForm__WEBPACK_IMPORTED_MODULE_5__, _Comment_Comment__WEBPACK_IMPORTED_MODULE_6__, _NestedComment_NestedComment__WEBPACK_IMPORTED_MODULE_7__]);
([_CommentForm_CommentForm__WEBPACK_IMPORTED_MODULE_5__, _Comment_Comment__WEBPACK_IMPORTED_MODULE_6__, _NestedComment_NestedComment__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const GetCommentList = (0,_app_gql__WEBPACK_IMPORTED_MODULE_2__/* .gql */ .P)(`
 query Comments($slug: String) {
  me {
    id
  }
  comments(filters: { article: { Slug: { eq: $slug } }, Parent: null }) {
    data {
      id
      attributes {
        article {
          data {
            id
            attributes {
              Slug
            }
          }
        }
        Author {
          data {
            attributes {
              username
              Img {
                img {
                  data {
                    attributes {
                      url
                      hash
                    }
                  }
                }
              }
            }
          }
        }
        Content
        Children {
          data {
            attributes {
              Content
              createdAt
              updatedAt
              Likes {
                UserId
              }
              Dislikes {
                UserId
              }
              Author {
                data {
                  attributes {
                    username
                    Img {
                      img {
                        data {
                          attributes {
                            url
                            hash
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        createdAt
        updatedAt
        Likes {
          UserId
        }
        Dislikes {
          UserId
        }
      }
    }
  }
}
`);
const CommentList = ({ slug , articleID  })=>{
    const [result] = (0,urql__WEBPACK_IMPORTED_MODULE_3__.useQuery)({
        query: GetCommentList,
        variables: {
            slug
        }
    });
    const { data , fetching , error  } = result;
    const commentData = data?.comments;
    const userId = data?.me?.id;
    {
        console.log(error);
    }
    if (fetching && !data || fetching) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Other_Load_Load__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {});
    const parentCommentLength = Number(commentData?.data.length);
    const childCommentLength = Number(commentData?.data.forEach((comment)=>comment?.attributes?.Children?.data.length));
    const totalCommentLength = childCommentLength + parentCommentLength;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_9___default().commentList),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CommentHeader_CommentHeader__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                totalComments: totalCommentLength
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CommentForm_CommentForm__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                userId: String(userId),
                articleId: String(articleID),
                commentId: undefined,
                nested: false
            }),
            parentCommentLength > 0 && commentData?.data?.map((comment)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        comment?.attributes?.Content,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Comment_Comment__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            comment: comment?.attributes,
                            commentId: comment?.id,
                            userId: userId,
                            nested: false,
                            articleId: articleID
                        }, comment?.id),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NestedComment_NestedComment__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            child: comment?.attributes?.Children?.data,
                            userId: userId,
                            articleId: articleID
                        })
                    ]
                }))
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CommentList);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4997:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Comment_Comment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6613);
/* harmony import */ var _Comments_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2124);
/* harmony import */ var _Comments_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Comments_module_scss__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Comment_Comment__WEBPACK_IMPORTED_MODULE_2__]);
_Comment_Comment__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const NestedComment = ({ child , userId , articleId  })=>{
    const { 0: openReplies , 1: setOpenReplies  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const commentNumber = Number(child?.length);
    const handleChange = ()=>{
        setOpenReplies(!openReplies);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_3___default().commentNested),
        children: [
            commentNumber > 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                className: (_Comments_module_scss__WEBPACK_IMPORTED_MODULE_3___default().commentViewMore),
                onClick: handleChange,
                children: [
                    "View ",
                    commentNumber,
                    " ",
                    commentNumber > 1 ? "Comments" : "Comment"
                ]
            }),
            openReplies && commentNumber > 0 && child?.map((comment, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Comment_Comment__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        nested: true,
                        comment: comment.attributes,
                        userId: userId,
                        articleId: String(articleId)
                    }, index)
                }))
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NestedComment);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8117:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Other_Img_Img__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4405);
/* harmony import */ var _CoverImg_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5181);
/* harmony import */ var _CoverImg_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_CoverImg_module_scss__WEBPACK_IMPORTED_MODULE_3__);




const Image = (PostImg)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_CoverImg_module_scss__WEBPACK_IMPORTED_MODULE_3___default().postImg),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                children: PostImg.title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Other_Img_Img__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                class: (_CoverImg_module_scss__WEBPACK_IMPORTED_MODULE_3___default().postImg),
                url: PostImg.url,
                placeholder: PostImg.placeholder,
                alt: `Image for ${PostImg.alt}`
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Image);


/***/ }),

/***/ 8573:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _MobileHeader_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5987);
/* harmony import */ var _MobileHeader_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_MobileHeader_module_scss__WEBPACK_IMPORTED_MODULE_2__);



const MobileHeader = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
        className: (_MobileHeader_module_scss__WEBPACK_IMPORTED_MODULE_2___default().mobileHeader),
        href: "/blog",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
            children: "The Blog..."
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MobileHeader);


/***/ }),

/***/ 6051:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _app_gql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1265);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Other_Load_Load__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2151);
/* harmony import */ var _components_Other_Error_Error__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7874);
/* harmony import */ var _components_Other_Meta_Meta__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4617);
/* harmony import */ var _components_Other_Layout_Post_module_scss__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4067);
/* harmony import */ var _components_Other_Layout_Post_module_scss__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_components_Other_Layout_Post_module_scss__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_Nav_NewNav__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8355);
/* harmony import */ var _components_Blog_Post_MobileHeader_MobileHeader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8573);
/* harmony import */ var _components_Blog_Post_CoverImg_CoverImg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8117);
/* harmony import */ var _components_Blog_Post_Body_Body__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8357);
/* harmony import */ var _components_Blog_Post_Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5874);
/* harmony import */ var _components_Nav_Footer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1783);
/* harmony import */ var _components_Blog_Post_Comments_CommentList_CommentList__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8901);
/* harmony import */ var _gql_urqlClient__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5639);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Blog_Post_Body_Body__WEBPACK_IMPORTED_MODULE_11__, _components_Blog_Post_Comments_CommentList_CommentList__WEBPACK_IMPORTED_MODULE_14__]);
([_components_Blog_Post_Body_Body__WEBPACK_IMPORTED_MODULE_11__, _components_Blog_Post_Comments_CommentList_CommentList__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












// import TagList from '../../components/Blog/Post/Tags/TagList';
// import Tags from '../../components/Blog/Post/Tags/Tag/Tags';





// import { GetArticlesQuery } from '../blog';
// import { isSignedIn } from '../../apollo/apolloClient';
// import Modal from '../../components/Other/SocialAuth/Modal';
const getBlogSlugs = (0,_app_gql__WEBPACK_IMPORTED_MODULE_2__/* .gql */ .P)(`
query Articles {
  articles {
    data {
      id
      attributes {
        Slug
      }
    }
  }
}
`);
const getArticle = (0,_app_gql__WEBPACK_IMPORTED_MODULE_2__/* .gql */ .P)(`
  query Article($slug: String) {
    ...NavigationFragment
    articles(filters: { Slug: { eq: $slug } }) {
      data {
        id
        attributes {
          Slug
          Title
          Tagline
          Published
          Content
          Author {
            data {
              attributes {
                username
              }
            }
          }
          Cover {
            img {
              data {
                attributes {
                  url
                  hash
                }
              }
            }
          }
        }
      }
    }
    ...SidebarArticlesFragment
  }
`);
const Post = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const slug = router.query.slug;
    // const authenticated = isSignedIn();
    const [result] = (0,urql__WEBPACK_IMPORTED_MODULE_4__.useQuery)({
        query: getArticle,
        variables: {
            slug: String(slug)
        }
    });
    const { data , fetching , error  } = result;
    if (fetching && !data) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Other_Load_Load__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {});
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Other_Error_Error__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {});
    const articleData = data?.articles?.data[0].attributes;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Other_Meta_Meta__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                title: articleData?.Title,
                excerpt: String(articleData?.Tagline),
                imgUrl: articleData?.Cover?.img?.data?.attributes?.url,
                url: `/blog/${String(slug)}`
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: (_components_Other_Layout_Post_module_scss__WEBPACK_IMPORTED_MODULE_16___default().layout),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Nav_NewNav__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        navLink: data?.navLink
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Blog_Post_MobileHeader_MobileHeader__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Blog_Post_CoverImg_CoverImg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        title: String(articleData?.Title),
                        url: String(articleData?.Cover?.img?.data?.attributes?.url),
                        placeholder: `/uploads/sqip_${String(articleData?.Cover?.img?.data?.attributes?.hash)}.svg`,
                        alt: String(articleData?.Title)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Blog_Post_Body_Body__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        content: String(articleData?.Content)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Blog_Post_Sidebar_Sidebar__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        sidebar: data?.sidebar
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Blog_Post_Comments_CommentList_CommentList__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                        slug: String(slug),
                        articleID: String(data?.articles?.data[0].id)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Nav_Footer__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
                ]
            }, data?.articles?.data[0].id)
        ]
    });
};
Post.displayName = "Post";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Post);
async function getStaticPaths() {
    const { data  } = await _gql_urqlClient__WEBPACK_IMPORTED_MODULE_15__/* .client.query */ .L.query(getBlogSlugs).toPromise().catch((err)=>{
        throw new Error(`This is the error ${String(err)}`);
    });
    const slugArr = data?.articles?.data.map(({ attributes  })=>attributes?.Slug);
    const paths = slugArr?.map((slug)=>({
            params: {
                slug
            }
        }));
    return {
        paths,
        fallback: false
    };
}
async function getStaticProps(context) {
    const { params  } = context;
    const { slug  } = params;
    await _gql_urqlClient__WEBPACK_IMPORTED_MODULE_15__/* .client.query */ .L.query(getArticle, {
        slug
    }).toPromise();
    return {
        props: {
            urqlState: _gql_urqlClient__WEBPACK_IMPORTED_MODULE_15__/* .ssrCacheExchange.extractData */ .I.extractData()
        },
        revalidate: 1200
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2245:
/***/ ((module) => {

"use strict";
module.exports = require("moment");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 661:
/***/ ((module) => {

"use strict";
module.exports = require("react-moment");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2977:
/***/ ((module) => {

"use strict";
module.exports = require("urql");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ }),

/***/ 1908:
/***/ ((module) => {

"use strict";
module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 3135:
/***/ ((module) => {

"use strict";
module.exports = import("react-markdown");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,608,30,356,355,177,115,874], () => (__webpack_exec__(6051)));
module.exports = __webpack_exports__;

})();