(() => {
var exports = {};
exports.id = 335;
exports.ids = [335];
exports.modules = {

/***/ 647:
/***/ ((module) => {

// Exports
module.exports = {
	"form": "Contact_form__4E_4r",
	"name": "Contact_name__3wpgW",
	"email": "Contact_email__3DqWC",
	"message": "Contact_message__iJbty",
	"submit": "Contact_submit__kzzM1",
	"submitError": "Contact_submitError__5BMMT",
	"error": "Contact_error__bAT70"
};


/***/ }),

/***/ 78:
/***/ ((module) => {

// Exports
module.exports = {
	"modalOverlay": "Modal_modalOverlay__BjNJU",
	"modal": "Modal_modal__SO4Rf"
};


/***/ }),

/***/ 1383:
/***/ ((module) => {

// Exports
module.exports = {
	"layout": "Contact_layout__Y2F7O"
};


/***/ }),

/***/ 7114:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1908);
/* harmony import */ var _Modal_Modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7438);
/* harmony import */ var _Contact_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(647);
/* harmony import */ var _Contact_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_Contact_module_scss__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const sendEmail = (0,urql__WEBPACK_IMPORTED_MODULE_3__.gql)(`
mutation AddEmail($name: String!, $email: String!, $message: String!) {
  createContact(data: { Name: $name, Email: $email, Message: $message }) {
    data {
      attributes {
        Name
        Email
        Message
      }
    }
  }
}
`);
const contactSchema = yup__WEBPACK_IMPORTED_MODULE_2__.object({
    name: yup__WEBPACK_IMPORTED_MODULE_2__.string().min(2, `That's not a name!`).max(22).required(),
    email: yup__WEBPACK_IMPORTED_MODULE_2__.string().email(`That's not a real email!`).min(6, `That's not a real email!`).required(),
    message: yup__WEBPACK_IMPORTED_MODULE_2__.string().min(2, "What kind of message is that?").max(500).required()
});
const HideModal = (hide)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Modal_Modal__WEBPACK_IMPORTED_MODULE_6__/* .Modal */ .u, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                children: "Thanks for reaching out"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                children: `I'll get back to you shortly.`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                onClick: hide,
                children: "Close"
            })
        ]
    });
const Form = ()=>{
    const [addEmailResult, addEmail] = (0,urql__WEBPACK_IMPORTED_MODULE_3__.useMutation)(sendEmail);
    const { register , handleSubmit , formState , reset , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        mode: "onChange",
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__.yupResolver)(contactSchema)
    });
    const onSubmit = async (data)=>{
        await addEmail({
            variables: {
                name: data.name,
                email: data.email,
                message: data.message
            }
        });
        reset({
            name: "",
            email: "",
            message: ""
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_Contact_module_scss__WEBPACK_IMPORTED_MODULE_7___default().form),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            onSubmit: void handleSubmit(onSubmit),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    children: "Want to get in touch?"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_Contact_module_scss__WEBPACK_IMPORTED_MODULE_7___default().name),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "text",
                            ...register("name", {
                                required: true
                            }),
                            placeholder: "Your Name",
                            maxLength: 22,
                            minLength: 2
                        }),
                        errors.name && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: (_Contact_module_scss__WEBPACK_IMPORTED_MODULE_7___default().error),
                            children: errors.name.message
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_Contact_module_scss__WEBPACK_IMPORTED_MODULE_7___default().email),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "email",
                            ...register("email", {
                                required: true
                            }),
                            placeholder: "Your email",
                            minLength: 6
                        }),
                        errors.email && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: (_Contact_module_scss__WEBPACK_IMPORTED_MODULE_7___default().error),
                            children: errors.email.message
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_Contact_module_scss__WEBPACK_IMPORTED_MODULE_7___default().message),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                            ...register("message", {
                                required: true
                            }),
                            placeholder: "Your message",
                            maxLength: 500,
                            minLength: 2
                        }),
                        errors.message && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: (_Contact_module_scss__WEBPACK_IMPORTED_MODULE_7___default().error),
                            children: errors.message.message
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Modal_Modal__WEBPACK_IMPORTED_MODULE_6__/* .ToggleContent */ .U, {
                    toggle: (show)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            type: "submit",
                            className: (_Contact_module_scss__WEBPACK_IMPORTED_MODULE_7___default().submit),
                            onClick: (event)=>{
                                handleSubmit(onSubmit);
                                show(event);
                            },
                            disabled: !!addEmailResult.error || !formState.isValid || errors && addEmailResult.fetching,
                            children: "Submit"
                        }),
                    content: HideModal
                }),
                addEmailResult.error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: (_Contact_module_scss__WEBPACK_IMPORTED_MODULE_7___default().submitError),
                    children: "Error :( Please try again"
                })
            ]
        })
    });
};
Form.displayName = "Contact Form";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Form);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7438:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ ToggleContent),
/* harmony export */   "u": () => (/* binding */ Modal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6405);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Modal_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(78);
/* harmony import */ var _Modal_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Modal_module_scss__WEBPACK_IMPORTED_MODULE_3__);




const ToggleContent = ({ toggle , content  })=>{
    const { 0: isShown , 1: setIsShown  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const hide = ()=>setIsShown(false);
    const show = ()=>setIsShown(true);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            toggle(show),
            isShown && content(hide)
        ]
    });
};
const Modal = ({ children  })=>/*#__PURE__*/ react_dom__WEBPACK_IMPORTED_MODULE_2___default().createPortal(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_Modal_module_scss__WEBPACK_IMPORTED_MODULE_3___default().modalOverlay),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_Modal_module_scss__WEBPACK_IMPORTED_MODULE_3___default().modal),
            children: children
        })
    }), document.getElementById("__next"));
Modal.displayName = "Modal";


/***/ }),

/***/ 5639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ ssrCacheExchange),
/* harmony export */   "L": () => (/* binding */ client)
/* harmony export */ });
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_0__);

const serverSide = "undefined" === "undefined";
const ssrCacheExchange = (0,urql__WEBPACK_IMPORTED_MODULE_0__.ssrExchange)({
    isClient: !serverSide
});
const client = (0,urql__WEBPACK_IMPORTED_MODULE_0__.createClient)({
    url: String("https://api.tropicalt.ca/graphql"),
    exchanges: [
        urql__WEBPACK_IMPORTED_MODULE_0__.dedupExchange,
        urql__WEBPACK_IMPORTED_MODULE_0__.cacheExchange,
        ssrCacheExchange,
        urql__WEBPACK_IMPORTED_MODULE_0__.fetchExchange
    ],
    fetchOptions: ()=>{
        return {
            headers: {}
        };
    }
});



/***/ }),

/***/ 5210:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ContactPage),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Contact_Contact__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7114);
/* harmony import */ var _components_Nav_NewNav__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8355);
/* harmony import */ var _components_Other_Layout_Contact_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1383);
/* harmony import */ var _components_Other_Layout_Contact_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_components_Other_Layout_Contact_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_Other_Meta_Meta__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4617);
/* harmony import */ var _app_gql__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1265);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_Other_Load_Load__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2151);
/* harmony import */ var _components_Other_Error_Error__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7874);
/* harmony import */ var _gql_urqlClient__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5639);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Contact_Contact__WEBPACK_IMPORTED_MODULE_2__]);
_components_Contact_Contact__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const GetContactQuery = (0,_app_gql__WEBPACK_IMPORTED_MODULE_5__/* .gql */ .P)(`
  query GetContactPage {
    ...NavigationFragment
  }
`);
function ContactPage() {
    const [result] = (0,urql__WEBPACK_IMPORTED_MODULE_6__.useQuery)({
        query: GetContactQuery
    });
    const { data , fetching , error  } = result;
    if (fetching && !data) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Other_Load_Load__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {});
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Other_Error_Error__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {});
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        className: (_components_Other_Layout_Contact_module_scss__WEBPACK_IMPORTED_MODULE_10___default().layout),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Other_Meta_Meta__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                title: "T^T - Contact Me",
                excerpt: "Send me a message and let me know what you think",
                url: "/contact"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Nav_NewNav__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                navLink: data?.navLink
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Contact_Contact__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        ]
    });
};
async function getStaticProps() {
    await _gql_urqlClient__WEBPACK_IMPORTED_MODULE_9__/* .client.query */ .L.query(GetContactQuery).toPromise();
    return {
        props: {
            urqlState: _gql_urqlClient__WEBPACK_IMPORTED_MODULE_9__/* .ssrCacheExchange.extractData */ .I.extractData()
        },
        revalidate: 1200
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2977:
/***/ ((module) => {

"use strict";
module.exports = require("urql");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ }),

/***/ 1908:
/***/ ((module) => {

"use strict";
module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,30,355], () => (__webpack_exec__(5210)));
module.exports = __webpack_exports__;

})();