(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 8715:
/***/ ((module) => {

// Exports
module.exports = {
	"bio": "Bio_bio___xzod"
};


/***/ }),

/***/ 123:
/***/ ((module) => {

// Exports
module.exports = {
	"imageBanner": "Hero_imageBanner__TQaLF"
};


/***/ }),

/***/ 7828:
/***/ ((module) => {

// Exports
module.exports = {
	"recentAlbums": "RecentAlbums_recentAlbums___2LNO"
};


/***/ }),

/***/ 4803:
/***/ ((module) => {

// Exports
module.exports = {
	"recentArticles": "RecentPosts_recentArticles__IAkvc"
};


/***/ }),

/***/ 5779:
/***/ ((module) => {

// Exports
module.exports = {
	"layout": "Home_layout__14HVc"
};


/***/ }),

/***/ 5287:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export BiographyFragment */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3135);
/* harmony import */ var _app_gql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1265);
/* harmony import */ var _Other_Avatar_Avatar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9011);
/* harmony import */ var _Bio_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8715);
/* harmony import */ var _Bio_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_Bio_module_scss__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_markdown__WEBPACK_IMPORTED_MODULE_2__]);
react_markdown__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const BiographyFragment = (0,_app_gql__WEBPACK_IMPORTED_MODULE_3__/* .gql */ .P)(`
  fragment BiographyFragment on Query {
usersPermissionsUser(id:1){
  data{
    id
    attributes{
      Biography
      Img{
        img{
          data{
            id
            attributes{
              url
              hash
            }
          }
        }
      }
    }
  }
}}`);
const Bio = ({ usersPermissionsUser  })=>{
    const bioData = usersPermissionsUser?.data;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Bio_module_scss__WEBPACK_IMPORTED_MODULE_5___default().bio),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Other_Avatar_Avatar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                img: bioData?.attributes?.Img?.img
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_2__["default"], {
                children: String(bioData?.attributes?.Biography)
            })
        ]
    }, bioData?.id);
};
Bio.fragments = {
    BiographyFragment
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Bio);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4445:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_shared_lib_styled_jsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7561);
/* harmony import */ var next_dist_shared_lib_styled_jsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_shared_lib_styled_jsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Hero_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(123);
/* harmony import */ var _Hero_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_Hero_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Other_Img_Img__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4405);
/* harmony import */ var _app_gql__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1265);






const HeroFragment = (0,_app_gql__WEBPACK_IMPORTED_MODULE_4__/* .gql */ .P)(`
  fragment HeroFragment on Query {
  home {
    data {
      attributes {
        Hero {
          id
          Img {
            img {
              data {
                attributes {
                  url
                  hash
                }
              }
            }
          }
          Caption
        }
      }
    }
  }
}
`);
const Hero = ({ home  })=>{
    const heroData = home?.data?.attributes?.Hero;
    const { 0: currentIndex , 1: setCurrentIndex  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    const nextHero = ()=>{
        setCurrentIndex(currentIndex === Number(heroData?.length) - 1 ? 0 : currentIndex + 1);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const clear = setInterval(nextHero, 5000);
        return ()=>{
            clearTimeout(clear);
        };
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: heroData && heroData.map((heroData, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    animation: `${currentIndex === index ? "fadeInOut" : "fadeOut"} 5s infinite ease-in-out`
                },
                className: "jsx-e41aeb6ba96301ea" + " " + ((_Hero_module_scss__WEBPACK_IMPORTED_MODULE_5___default().imageBanner) || ""),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "jsx-e41aeb6ba96301ea",
                        children: heroData?.Caption
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Other_Img_Img__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        id: heroData?.id,
                        class: (_Hero_module_scss__WEBPACK_IMPORTED_MODULE_5___default().imageBanner),
                        url: heroData?.Img?.[0]?.img?.data?.attributes?.url,
                        placeholder: `/uploads/sqip_${String(heroData?.Img?.[0]?.img?.data?.attributes?.hash)}.svg`,
                        alt: `Image for ${String(heroData?.Caption)}`
                    }, heroData?.id),
                    react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_dist_shared_lib_styled_jsx__WEBPACK_IMPORTED_MODULE_1___default()), {
                        id: "e41aeb6ba96301ea",
                        children: "@-webkit-keyframes fadeInOut{0%{opacity:0;-webkit-animation-timing-function:ease-in;animation-timing-function:ease-in}10%{opacity:1;-webkit-animation-timing-function:ease-out;animation-timing-function:ease-out}85%{opacity:1}100%{opacity:0}}@-moz-keyframes fadeInOut{0%{opacity:0;-moz-animation-timing-function:ease-in;animation-timing-function:ease-in}10%{opacity:1;-moz-animation-timing-function:ease-out;animation-timing-function:ease-out}85%{opacity:1}100%{opacity:0}}@-o-keyframes fadeInOut{0%{opacity:0;-o-animation-timing-function:ease-in;animation-timing-function:ease-in}10%{opacity:1;-o-animation-timing-function:ease-out;animation-timing-function:ease-out}85%{opacity:1}100%{opacity:0}}@keyframes fadeInOut{0%{opacity:0;-webkit-animation-timing-function:ease-in;-moz-animation-timing-function:ease-in;-o-animation-timing-function:ease-in;animation-timing-function:ease-in}10%{opacity:1;-webkit-animation-timing-function:ease-out;-moz-animation-timing-function:ease-out;-o-animation-timing-function:ease-out;animation-timing-function:ease-out}85%{opacity:1}100%{opacity:0}}@-webkit-keyframes fadeOut{0%{opacity:0}100%{opacity:0}}@-moz-keyframes fadeOut{0%{opacity:0}100%{opacity:0}}@-o-keyframes fadeOut{0%{opacity:0}100%{opacity:0}}@keyframes fadeOut{0%{opacity:0}100%{opacity:0}}"
                    })
                ]
            }, heroData?.id))
    });
};
Hero.fragments = {
    HeroFragment
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);


/***/ }),

/***/ 1274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export RecentAlbumsFragment */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _app_gql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1265);
/* harmony import */ var _Recents__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9177);
/* harmony import */ var _RecentAlbums_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7828);
/* harmony import */ var _RecentAlbums_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_RecentAlbums_module_scss__WEBPACK_IMPORTED_MODULE_4__);





const RecentAlbumsFragment = (0,_app_gql__WEBPACK_IMPORTED_MODULE_2__/* .gql */ .P)(`
  fragment RecentAlbumsFragment on Query {
      albums(sort: "Date:desc", pagination: { start: 0, limit: 4 }) {
    data {
      id
      attributes {
        Slug
        Name
        Tagline
        Date
        Location
        Photographer {
          data {
            attributes {
              username
            }
          }
        }
        Cover {
          img {
            data {
              attributes {
                url
                hash
              }
            }
          }
        }
      }
    }
  }
  }
`);
const Albums = ({ albums  })=>{
    const albumData = albums?.data;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_RecentAlbums_module_scss__WEBPACK_IMPORTED_MODULE_4___default().recentAlbums),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                children: "Recent Albums"
            }),
            albumData?.map((album)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Recents__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    id: String(album?.id),
                    type: "albums",
                    slug: String(album?.attributes?.Slug),
                    cover: `/uploads/sqip_${String(album?.attributes?.Cover?.img?.data?.attributes?.hash)}.svg`,
                    img: String(album?.attributes?.Cover?.img?.data?.attributes?.url),
                    title: String(album?.attributes?.Name),
                    date: String(album?.attributes?.Date),
                    name: String(album?.attributes?.Photographer?.data?.attributes?.username),
                    excerpt: `Location: ${String(album?.attributes?.Location)}`
                }, album?.id))
        ]
    });
};
Albums.displayName = "Recent Albums";
Albums.fragments = {
    RecentAlbumsFragment
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Albums);


/***/ }),

/***/ 3903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export RecentArticlesFragment */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _app_gql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1265);
/* harmony import */ var _Recents__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9177);
/* harmony import */ var _RecentPosts_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4803);
/* harmony import */ var _RecentPosts_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_RecentPosts_module_scss__WEBPACK_IMPORTED_MODULE_4__);





const RecentArticlesFragment = (0,_app_gql__WEBPACK_IMPORTED_MODULE_2__/* .gql */ .P)(`
  fragment RecentArticlesFragment on Query {
 articles(sort:"Published:desc", pagination: { start: 0, limit: 3}){
    data {
      id
      attributes {
        Slug
        Title
        Tagline
        Published
        Author{
          data{
            attributes{
              username
            }
          }
        }
        Cover {
          img {
            data {
              attributes {
                url
                hash
              }
            }
          }
        }
      }
    }
  }
  }
`);
const Articles = ({ articles  })=>{
    const articleData = articles?.data;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_RecentPosts_module_scss__WEBPACK_IMPORTED_MODULE_4___default().recentArticles),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                children: "Recent Posts"
            }),
            articleData?.map((article)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Recents__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    id: String(article?.id),
                    type: "blog",
                    slug: String(article?.attributes?.Slug),
                    cover: `/uploads/sqip_${String(article?.attributes?.Cover?.img?.data?.attributes?.hash)}.svg`,
                    img: String(article?.attributes?.Cover?.img?.data?.attributes?.url),
                    title: String(article?.attributes?.Title),
                    date: String(article?.attributes?.Published),
                    name: String(article?.attributes?.Author?.data?.attributes?.username),
                    excerpt: String(article?.attributes?.Tagline)
                }, article?.id))
        ]
    });
};
Articles.displayName = "Recent Articles";
Articles.fragments = {
    RecentArticlesFragment
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Articles);


/***/ }),

/***/ 5075:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Nav_Footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1783);
/* harmony import */ var _components_Home_Recents_Posts_RecentPosts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3903);
/* harmony import */ var _components_Home_Recents_Albums_RecentAlbums__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1274);
/* harmony import */ var _components_Home_Hero_Hero__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4445);
/* harmony import */ var _components_Home_Bio_Bio__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5287);
/* harmony import */ var _components_Other_Layout_Home_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5779);
/* harmony import */ var _components_Other_Layout_Home_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_components_Other_Layout_Home_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_Other_Meta_Meta__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4617);
/* harmony import */ var _components_Other_Load_Load__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2151);
/* harmony import */ var _components_Other_Error_Error__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7874);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _app_gql__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1265);
/* harmony import */ var _gql_urqlClient__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5639);
/* harmony import */ var _components_Nav_NewNav__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8355);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Home_Bio_Bio__WEBPACK_IMPORTED_MODULE_6__]);
_components_Home_Bio_Bio__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];















const GetHomepageQuery = (0,_app_gql__WEBPACK_IMPORTED_MODULE_11__/* .gql */ .P)(`
  query GetHomePage {
    ...NavigationFragment
    ...HeroFragment
    ...BiographyFragment
    ...RecentArticlesFragment
    ...RecentAlbumsFragment
  }
`);
function Home() {
    const [result] = (0,urql__WEBPACK_IMPORTED_MODULE_10__.useQuery)({
        query: GetHomepageQuery
    });
    const { data , error , fetching  } = result;
    if (fetching && !data) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Other_Load_Load__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {});
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Other_Error_Error__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {});
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        className: (_components_Other_Layout_Home_module_scss__WEBPACK_IMPORTED_MODULE_14___default().layout),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Other_Meta_Meta__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                title: "T^T - TropicalT",
                excerpt: "The homepage of Thomas Fiala",
                imgUrl: data?.usersPermissionsUser?.data?.attributes?.Img?.img?.data?.attributes?.url,
                url: "/"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Nav_NewNav__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                navLink: data?.navLink
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Home_Hero_Hero__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                home: data?.home
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Home_Bio_Bio__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                usersPermissionsUser: data?.usersPermissionsUser
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Home_Recents_Posts_RecentPosts__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                articles: data?.articles
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Home_Recents_Albums_RecentAlbums__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                albums: data?.albums
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Nav_Footer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        ]
    });
};
async function getStaticProps() {
    await _gql_urqlClient__WEBPACK_IMPORTED_MODULE_12__/* .client.query */ .L.query(GetHomepageQuery).toPromise();
    return {
        props: {
            urqlState: _gql_urqlClient__WEBPACK_IMPORTED_MODULE_12__/* .ssrCacheExchange.extractData */ .I.extractData()
        },
        revalidate: 1200
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 7561:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/styled-jsx");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 661:
/***/ ((module) => {

"use strict";
module.exports = require("react-moment");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2977:
/***/ ((module) => {

"use strict";
module.exports = require("urql");

/***/ }),

/***/ 3135:
/***/ ((module) => {

"use strict";
module.exports = import("react-markdown");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,608,30,356,355,177,115], () => (__webpack_exec__(5075)));
module.exports = __webpack_exports__;

})();