(() => {
var exports = {};
exports.id = 647;
exports.ids = [647];
exports.modules = {

/***/ 9555:
/***/ ((module) => {

// Exports
module.exports = {
	"layout": "Resume_layout__Tc82_"
};


/***/ }),

/***/ 5680:
/***/ ((module) => {

// Exports
module.exports = {
	"name": "Resume_name__8a0Su",
	"T": "Resume_T__JWlXC",
	"A": "Resume_A__Vkp2c",
	"F": "Resume_F__kr3Ui",
	"contactInfo": "Resume_contactInfo__qVKAe",
	"address": "Resume_address__1u1Wo",
	"cellphone": "Resume_cellphone__uRCyc",
	"workHistory": "Resume_workHistory__rTmKL",
	"education": "Resume_education__W30rZ",
	"highlightImg": "Resume_highlightImg___xV4V",
	"skills": "Resume_skills__NzLTE",
	"hobbies": "Resume_hobbies__EKGMv",
	"skill": "Resume_skill__eKE8i",
	"contact": "Resume_contact__0gq_O"
};


/***/ }),

/***/ 4794:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export ContactFragment */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5680);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Resume_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_2__);




const ContactFragment = urql__WEBPACK_IMPORTED_MODULE_2__.gql`
  fragment ContactFragment on Resume {
    Address
    Phone
  }
`;
const Contact = ({ phoneNum , address  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_3___default().contactInfo),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_3___default().cellphone),
                children: phoneNum
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_3___default().address),
                children: address
            })
        ]
    });
};
Contact.displayName = "Contact Info";
Contact.fragments = {
    ContactFragment: ContactFragment
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Contact);


/***/ }),

/***/ 2646:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export EducationFragment */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3135);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5680);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Resume_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_markdown__WEBPACK_IMPORTED_MODULE_2__]);
react_markdown__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const EducationFragment = urql__WEBPACK_IMPORTED_MODULE_3__.gql`
  fragment EducationFragment on Resume {
    Education
  }
`;
const Education = ({ edu  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_4___default().education),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                children: "Education"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_2__["default"], {
                children: edu
            })
        ]
    });
};
Education.displayName = "Education";
Education.fragments = {
    EducationFragment: EducationFragment
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Education);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9381:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export HobbiesFragment */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3135);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5680);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Resume_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_markdown__WEBPACK_IMPORTED_MODULE_2__]);
react_markdown__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const HobbiesFragment = (0,urql__WEBPACK_IMPORTED_MODULE_3__.gql)(`
  fragment HobbiesFragment on Resume {
    Hobbies
  }
`);
const Hobbies = ({ hobbies  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_4___default().hobbies),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                children: "Hobbies"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_2__["default"], {
                children: hobbies
            })
        ]
    });
};
Hobbies.displayName = "My Hobbies";
Hobbies.fragments = {
    HobbiesFragment: HobbiesFragment
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hobbies);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export HighlightImgFragment */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Other_Img_Img__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4405);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5680);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Resume_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_3__);





const HighlightImgFragment = urql__WEBPACK_IMPORTED_MODULE_3__.gql`
  fragment HighlightImgFragment on Resume {
    Img {
      img {
        data {
          id
          attributes {
            url
            hash
          }
        }
      }
    }
  }
`;
const Highlight = ({ highlight  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_4___default().highlightImg),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Other_Img_Img__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            class: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_4___default().highlightImg),
            url: String(highlight?.img?.data?.attributes?.url),
            placeholder: `/uploads/sqip_${String(highlight?.img?.data?.attributes?.hash)}.svg`,
            alt: `Image for Resume`
        })
    });
};
Highlight.displayName = "Contact Info";
Highlight.fragments = {
    HighlightImgFragment: HighlightImgFragment
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Highlight);


/***/ }),

/***/ 1598:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export ResumeEmailFragment */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5680);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Resume_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _app_gql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1265);




const ResumeEmailFragment = (0,_app_gql__WEBPACK_IMPORTED_MODULE_2__/* .gql */ .P)(`
  fragment ResumeEmailFragment on Resume {
    email
  }
`);
const Email = ({ email  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_3___default().contact),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
            children: [
                "Contact Information:",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: `mailto:${email}`,
                    children: "Email"
                })
            ]
        })
    });
};
Email.displayName = "Footer";
Email.fragments = {
    ResumeEmailFragment: ResumeEmailFragment
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Email);


/***/ }),

/***/ 4508:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5680);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Resume_module_scss__WEBPACK_IMPORTED_MODULE_3__);




const Header = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_3___default().name),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_3___default()["return"]),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: "/",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        children: "Return to T_T"
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_3___default().T),
                children: "Thomas"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_3___default().A),
                children: "Alexander"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_3___default().F),
                children: "Fiala"
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);


/***/ }),

/***/ 4792:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export SkillsFragment */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3135);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5680);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Resume_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_markdown__WEBPACK_IMPORTED_MODULE_2__]);
react_markdown__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const SkillsFragment = urql__WEBPACK_IMPORTED_MODULE_3__.gql`
  fragment SkillsFragment on Resume {
    Skills
  }
`;
const Skills = ({ skills  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_4___default().skills),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                children: "Skills"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_2__["default"], {
                children: skills
            })
        ]
    });
};
Skills.displayName = "My Skills";
Skills.fragments = {
    SkillsFragment: SkillsFragment
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Skills);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4376:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export WorkExpFragment */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_markdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3135);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5680);
/* harmony import */ var _Resume_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Resume_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_markdown__WEBPACK_IMPORTED_MODULE_2__]);
react_markdown__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const WorkExpFragment = urql__WEBPACK_IMPORTED_MODULE_3__.gql`
  fragment WorkExpFragment on Resume {
    Experience
  }
`;
const WorkExp = ({ workExp  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_Resume_module_scss__WEBPACK_IMPORTED_MODULE_4___default().workHistory),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                children: "Work History"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_markdown__WEBPACK_IMPORTED_MODULE_2__["default"], {
                children: workExp
            })
        ]
    });
};
WorkExp.displayName = "Work Experience";
WorkExp.fragments = {
    WorkExpFragment: WorkExpFragment
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WorkExp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1665:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ResumePage),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Other_Layout_Resume_module_scss__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9555);
/* harmony import */ var _components_Other_Layout_Resume_module_scss__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_components_Other_Layout_Resume_module_scss__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_Other_Meta_Meta__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4617);
/* harmony import */ var _app_gql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1265);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2977);
/* harmony import */ var urql__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(urql__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_Other_Error_Error__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7874);
/* harmony import */ var _components_Resume_Skills_Skills__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4792);
/* harmony import */ var _components_Resume_WorkExp_WorkExp__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4376);
/* harmony import */ var _components_Resume_Hobbies_Hobbies__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9381);
/* harmony import */ var _components_Resume_Contact_Contact__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4794);
/* harmony import */ var _components_Resume_Education_Education__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2646);
/* harmony import */ var _components_Resume_Image_Image__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4134);
/* harmony import */ var _components_Resume_Nav_Footer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1598);
/* harmony import */ var _components_Other_Load_Load__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2151);
/* harmony import */ var _components_Resume_Nav_Header__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4508);
/* harmony import */ var _gql_urqlClient__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5639);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Resume_Skills_Skills__WEBPACK_IMPORTED_MODULE_6__, _components_Resume_WorkExp_WorkExp__WEBPACK_IMPORTED_MODULE_7__, _components_Resume_Hobbies_Hobbies__WEBPACK_IMPORTED_MODULE_8__, _components_Resume_Education_Education__WEBPACK_IMPORTED_MODULE_10__]);
([_components_Resume_Skills_Skills__WEBPACK_IMPORTED_MODULE_6__, _components_Resume_WorkExp_WorkExp__WEBPACK_IMPORTED_MODULE_7__, _components_Resume_Hobbies_Hobbies__WEBPACK_IMPORTED_MODULE_8__, _components_Resume_Education_Education__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const GetResumeQuery = (0,_app_gql__WEBPACK_IMPORTED_MODULE_3__/* .gql */ .P)(`
  query GetResumeQuery {
    resume {
      data {
        id
        attributes {
          ...ContactFragment
          ...WorkExpFragment
          ...EducationFragment
          ...SkillsFragment
          ...HighlightImgFragment
          ...HobbiesFragment
          ...ResumeEmailFragment
        }
      }
    }
  }
`);
function ResumePage() {
    const [result] = (0,urql__WEBPACK_IMPORTED_MODULE_4__.useQuery)({
        query: GetResumeQuery
    });
    const { data , fetching , error  } = result;
    if (fetching && !data) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Other_Load_Load__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {});
    if (error) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Other_Error_Error__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {});
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        className: (_components_Other_Layout_Resume_module_scss__WEBPACK_IMPORTED_MODULE_16___default().layout),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Other_Meta_Meta__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                title: "T^T - Resume",
                excerpt: `Thomas Fiala's Current Resume`,
                imgUrl: data?.resume?.data?.attributes?.Img?.img?.data?.attributes?.url,
                url: "/resume"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Resume_Nav_Header__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Resume_Contact_Contact__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                address: String(data?.resume?.data?.attributes?.Address),
                phoneNum: String(data?.resume?.data?.attributes?.Phone)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Resume_WorkExp_WorkExp__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                workExp: String(data?.resume?.data?.attributes?.Experience)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Resume_Education_Education__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                edu: String(data?.resume?.data?.attributes?.Education)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Resume_Skills_Skills__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                skills: String(data?.resume?.data?.attributes?.Skills)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Resume_Image_Image__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                highlight: data?.resume?.data?.attributes?.Img
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Resume_Hobbies_Hobbies__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                hobbies: String(data?.resume?.data?.attributes?.Hobbies)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Resume_Nav_Footer__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                email: String(data?.resume?.data?.attributes?.email)
            })
        ]
    });
};
ResumePage.displayName = "Resume";
async function getStaticProps() {
    await _gql_urqlClient__WEBPACK_IMPORTED_MODULE_15__/* .client.query */ .L.query(GetResumeQuery).toPromise();
    return {
        props: {
            urqlState: _gql_urqlClient__WEBPACK_IMPORTED_MODULE_15__/* .ssrCacheExchange.extractData */ .I.extractData()
        },
        revalidate: 1200
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2977:
/***/ ((module) => {

"use strict";
module.exports = require("urql");

/***/ }),

/***/ 3135:
/***/ ((module) => {

"use strict";
module.exports = import("react-markdown");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,608,30,356], () => (__webpack_exec__(1665)));
module.exports = __webpack_exports__;

})();