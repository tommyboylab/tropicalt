module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 9);
/******/ })
/************************************************************************/
/******/ ({

/***/ "+2qL":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"layout": "Contact_layout__29iEo"
};


/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "8zEA":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("4Q3z");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;



const getStyle = (router, href) => ({
  // color: router.pathname.split('/').pop()
  // 	.includes(href)
  // 	? 'rgb(190, 55, 250)'
  // 	: 'rgba(190, 55, 250, .35)',
  color: router.pathname === href ? 'rgb(190, 55, 250)' : 'rgba(190, 55, 250, .35)'
});

const ActiveLink = ({
  children,
  router,
  href
}) => {
  const style = getStyle(router, href);
  const handleClick = Object(react__WEBPACK_IMPORTED_MODULE_1__["useCallback"])(e => {
    e.preventDefault();
    router.push(href).then(() => window.scrollTo(0, 0));
  }, []);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("a", {
    href: href,
    onClick: handleClick,
    style: style
  }, children);
};

/* harmony default export */ __webpack_exports__["a"] = (Object(next_router__WEBPACK_IMPORTED_MODULE_0__["withRouter"])(ActiveLink));

/***/ }),

/***/ 9:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("qARc");


/***/ }),

/***/ "BTiB":
/***/ (function(module, exports) {

module.exports = require("react-hook-form");

/***/ }),

/***/ "C8TP":
/***/ (function(module, exports) {

module.exports = require("yup");

/***/ }),

/***/ "DTfP":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Load_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("wiZR");
/* harmony import */ var _Load_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Load_module_scss__WEBPACK_IMPORTED_MODULE_1__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;



const Loading = () => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
  className: _Load_module_scss__WEBPACK_IMPORTED_MODULE_1___default.a.load,
  src: "/static/load.gif",
  alt: "Loading..."
});

/* harmony default export */ __webpack_exports__["a"] = (Loading);

/***/ }),

/***/ "FMea":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("xnum");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;



const Meta = ({
  title,
  excerpt,
  imgUrl,
  url
}) => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("title", null, title), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
  name: "title",
  content: title
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
  name: "description",
  content: excerpt
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
  property: "og:type",
  content: "website"
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
  property: "og:url",
  content: `https://tropicalt.ca${url}`
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
  property: "og:title",
  content: title
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
  property: "og:description",
  content: excerpt
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
  property: "og:image",
  content: `https://api.tropicalt.ca${imgUrl}`
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
  property: "twitter:card",
  content: "summary_large_image"
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
  property: "twitter:url",
  content: `https://tropicalt.ca${url}`
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
  property: "twitter:title",
  content: title
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
  property: "twitter:description",
  content: excerpt
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("meta", {
  property: "twitter:image",
  content: `https://api.tropicalt.ca${imgUrl}`
}));

Meta.displayName = 'MetaTags';
/* harmony default export */ __webpack_exports__["a"] = (Meta);

/***/ }),

/***/ "HJQg":
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ }),

/***/ "NnWi":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"nav": "Nav_nav__3624A",
	"menu": "Nav_menu__ouc51"
};


/***/ }),

/***/ "QvmT":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Error_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("uI0f");
/* harmony import */ var _Error_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_Error_module_scss__WEBPACK_IMPORTED_MODULE_1__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;



const Err = () => /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
  className: _Error_module_scss__WEBPACK_IMPORTED_MODULE_1___default.a.error
}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("img", {
  src: "/static/err.png",
  alt: `You've found an error my friend!'`
}), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h2", null, "Who you gonna call?"));

/* harmony default export */ __webpack_exports__["a"] = (Err);

/***/ }),

/***/ "Rwme":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"form": "Contact_form__2tvZm",
	"name": "Contact_name__6KuzJ",
	"email": "Contact_email__1DcNP",
	"message": "Contact_message__1fTmD",
	"submit": "Contact_submit__3Z6IQ",
	"submitError": "Contact_submitError__JjS9I",
	"error": "Contact_error__1Ge7P"
};


/***/ }),

/***/ "WGwd":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("HJQg");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("txk1");
/* harmony import */ var graphql_tag__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(graphql_tag__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ActiveLink_ActiveLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("8zEA");
/* harmony import */ var _Nav_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("NnWi");
/* harmony import */ var _Nav_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Nav_module_scss__WEBPACK_IMPORTED_MODULE_4__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;




const NavFragment = graphql_tag__WEBPACK_IMPORTED_MODULE_2___default.a`
  fragment NavigationFragment on Query {
    nav(id: 1) {
      nav {
        id
        title
        url
      }
    }
  }
`;

const Nav = nav => {
  var _nav$data, _nav$data$nav;

  nav = (_nav$data = nav.data) === null || _nav$data === void 0 ? void 0 : (_nav$data$nav = _nav$data.nav) === null || _nav$data$nav === void 0 ? void 0 : _nav$data$nav.nav;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("nav", {
    className: _Nav_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.nav
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", {
    className: _Nav_module_scss__WEBPACK_IMPORTED_MODULE_4___default.a.menu
  }, "T^T"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("ul", {
    className: "jsx-1323942325"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
    id: "1323942325"
  }, [".link.active.jsx-1323942325:after{height:-0.2em;text-align:center;content:' -------';}"]), nav && nav.map(nav => {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(_ActiveLink_ActiveLink__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"], {
      href: nav.url,
      key: nav.id
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("li", {
      className: "jsx-1323942325" + " " + 'link'
    }, nav.title));
  })));
};

Nav.displayName = 'Nav';
Nav.fragments = {
  NavigationFragment: NavFragment
};
/* harmony default export */ __webpack_exports__["a"] = (Nav);

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "faye":
/***/ (function(module, exports) {

module.exports = require("react-dom");

/***/ }),

/***/ "ku0o":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"modalOverlay": "Modal_modalOverlay__2cS9C",
	"modal": "Modal_modal__Ea1Ib"
};


/***/ }),

/***/ "mU8t":
/***/ (function(module, exports) {

module.exports = require("@apollo/react-hooks");

/***/ }),

/***/ "qARc":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "default", function() { return /* binding */ ContactPage; });

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__("C8TP");

// EXTERNAL MODULE: external "graphql-tag"
var external_graphql_tag_ = __webpack_require__("txk1");
var external_graphql_tag_default = /*#__PURE__*/__webpack_require__.n(external_graphql_tag_);

// EXTERNAL MODULE: external "@apollo/react-hooks"
var react_hooks_ = __webpack_require__("mU8t");

// EXTERNAL MODULE: external "react-hook-form"
var external_react_hook_form_ = __webpack_require__("BTiB");

// EXTERNAL MODULE: external "react-dom"
var external_react_dom_ = __webpack_require__("faye");
var external_react_dom_default = /*#__PURE__*/__webpack_require__.n(external_react_dom_);

// EXTERNAL MODULE: ./components/Contact/Modal/Modal.module.scss
var Modal_module = __webpack_require__("ku0o");
var Modal_module_default = /*#__PURE__*/__webpack_require__.n(Modal_module);

// CONCATENATED MODULE: ./components/Contact/Modal/Modal.tsx
var __jsx = external_react_default.a.createElement;



const ToggleContent = ({
  toggle,
  content
}) => {
  const {
    0: isShown,
    1: setIsShown
  } = Object(external_react_["useState"])(false);

  const hide = () => setIsShown(false);

  const show = () => setIsShown(true);

  return /*#__PURE__*/external_react_default.a.createElement(external_react_default.a.Fragment, null, toggle(show), isShown && content(hide));
};
const Modal = ({
  children
}) => external_react_dom_default.a.createPortal( /*#__PURE__*/external_react_default.a.createElement("div", {
  className: Modal_module_default.a.modalOverlay
}, /*#__PURE__*/external_react_default.a.createElement("div", {
  className: Modal_module_default.a.modal
}, children)), document.getElementById('__next'));
Modal.displayName = 'Modal';
// EXTERNAL MODULE: ./components/Contact/Contact.module.scss
var Contact_module = __webpack_require__("Rwme");
var Contact_module_default = /*#__PURE__*/__webpack_require__.n(Contact_module);

// CONCATENATED MODULE: ./components/Contact/Contact.tsx
var Contact_jsx = external_react_default.a.createElement;







const sendEmail = external_graphql_tag_default.a`
  mutation AddEmail($name: String!, $email: String!, $message: String!) {
    createEmail(input: { data: { name: $name, email: $email, message: $message } }) {
      email {
        id
        name
        email
        message
      }
    }
  }
`;
const contactSchema = Object(external_yup_["object"])().shape({
  name: Object(external_yup_["string"])().min(2, `That's not a name!`).max(22).required(),
  email: Object(external_yup_["string"])().email(`That's not a real email!`).min(6, `That's not a real email!`).required(),
  message: Object(external_yup_["string"])().min(2, 'What kind of message is that?').max(500).required()
});

const HideModal = hide => /*#__PURE__*/external_react_default.a.createElement(Modal, null, /*#__PURE__*/external_react_default.a.createElement("h2", null, "Thanks for reaching out"), /*#__PURE__*/external_react_default.a.createElement("p", null, `I'll get back to you shortly.`), /*#__PURE__*/external_react_default.a.createElement("button", {
  onClick: hide
}, "Close"));

const Form = () => {
  const [addEmail, {
    loading: mutationLoading,
    error: mutationError
  }] = Object(react_hooks_["useMutation"])(sendEmail);
  const {
    register,
    errors,
    handleSubmit,
    formState,
    reset
  } = Object(external_react_hook_form_["useForm"])({
    mode: 'onChange',
    // @ts-ignore
    validationSchema: contactSchema
  });

  const onSubmit = async data => {
    await addEmail({
      variables: {
        name: data.name,
        email: data.email,
        message: data.message
      }
    });
    reset({
      name: '',
      email: '',
      message: ''
    });
  };

  return /*#__PURE__*/external_react_default.a.createElement("section", {
    className: Contact_module_default.a.form
  }, /*#__PURE__*/external_react_default.a.createElement("form", {
    onSubmit: handleSubmit(onSubmit)
  }, /*#__PURE__*/external_react_default.a.createElement("h1", null, "Want to get in touch?"), /*#__PURE__*/external_react_default.a.createElement("div", {
    className: Contact_module_default.a.name
  }, /*#__PURE__*/external_react_default.a.createElement("input", {
    type: "text",
    placeholder: "Your Name",
    name: "name",
    ref: register,
    maxLength: 22,
    minLength: 2,
    required: true
  }), errors.name && /*#__PURE__*/external_react_default.a.createElement("p", {
    className: Contact_module_default.a.error
  }, errors.name.message)), /*#__PURE__*/external_react_default.a.createElement("div", {
    className: Contact_module_default.a.email
  }, /*#__PURE__*/external_react_default.a.createElement("input", {
    type: "email",
    placeholder: "Your email",
    name: "email",
    ref: register,
    minLength: 6,
    required: true
  }), errors.email && /*#__PURE__*/external_react_default.a.createElement("p", {
    className: Contact_module_default.a.error
  }, errors.email.message)), /*#__PURE__*/external_react_default.a.createElement("div", {
    className: Contact_module_default.a.message
  }, /*#__PURE__*/external_react_default.a.createElement("textarea", {
    placeholder: "Your message",
    name: "message",
    ref: register,
    maxLength: 500,
    minLength: 2,
    required: true
  }), errors.message && /*#__PURE__*/external_react_default.a.createElement("p", {
    className: Contact_module_default.a.error
  }, errors.message.message)), /*#__PURE__*/external_react_default.a.createElement(ToggleContent, {
    toggle: show => /*#__PURE__*/external_react_default.a.createElement("button", {
      type: "submit",
      className: Contact_module_default.a.submit,
      onClick: event => {
        handleSubmit(onSubmit);
        show(event);
      },
      disabled: !!mutationError || !formState.isValid || errors && mutationLoading
    }, "Submit"),
    content: HideModal
  }), mutationError && /*#__PURE__*/external_react_default.a.createElement("p", {
    className: Contact_module_default.a.submitError
  }, "Error :( Please try again")));
};

Form.displayName = 'Contact Form';
/* harmony default export */ var Contact = (Form);
// EXTERNAL MODULE: ./components/Nav/Nav.tsx
var Nav = __webpack_require__("WGwd");

// EXTERNAL MODULE: ./components/Other/Layout/Contact.module.scss
var Layout_Contact_module = __webpack_require__("+2qL");
var Layout_Contact_module_default = /*#__PURE__*/__webpack_require__.n(Layout_Contact_module);

// EXTERNAL MODULE: ./components/Other/Meta/Meta.tsx
var Meta = __webpack_require__("FMea");

// EXTERNAL MODULE: ./components/Other/Load/Load.tsx
var Load = __webpack_require__("DTfP");

// EXTERNAL MODULE: ./components/Other/Error/Error.tsx
var Error = __webpack_require__("QvmT");

// CONCATENATED MODULE: ./pages/contact.tsx
var contact_jsx = external_react_default.a.createElement;









const getContactQuery = external_graphql_tag_default.a`
  query getImageBanner {
    ...NavigationFragment
  }
  ${Nav["a" /* default */].fragments.NavigationFragment}
`;
function ContactPage() {
  const {
    data,
    error,
    loading
  } = Object(react_hooks_["useQuery"])(getContactQuery);
  if (loading && !data) return /*#__PURE__*/external_react_default.a.createElement(Load["a" /* default */], null);
  if (error) return /*#__PURE__*/external_react_default.a.createElement(Error["a" /* default */], null);
  return /*#__PURE__*/external_react_default.a.createElement("main", {
    className: Layout_Contact_module_default.a.layout
  }, /*#__PURE__*/external_react_default.a.createElement(Meta["a" /* default */], {
    title: 'T^T - Contact Me',
    excerpt: 'Send me a message and let me know what you think',
    url: '/contact'
  }), /*#__PURE__*/external_react_default.a.createElement(Nav["a" /* default */], {
    data: data
  }), /*#__PURE__*/external_react_default.a.createElement(Contact, null));
}

/***/ }),

/***/ "txk1":
/***/ (function(module, exports) {

module.exports = require("graphql-tag");

/***/ }),

/***/ "uI0f":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"error": "Error_error__2hl73"
};


/***/ }),

/***/ "wiZR":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"load": "Load_load__1PsGz"
};


/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ })

/******/ });