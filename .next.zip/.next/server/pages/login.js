module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 11);
/******/ })
/************************************************************************/
/******/ ({

/***/ 11:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("11/B");


/***/ }),

/***/ "11/B":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__("kG9d");

// EXTERNAL MODULE: external "react-dom"
var external_react_dom_ = __webpack_require__("faye");
var external_react_dom_default = /*#__PURE__*/__webpack_require__.n(external_react_dom_);

// EXTERNAL MODULE: ./components/Other/SocialAuth/Modal.module.scss
var Modal_module = __webpack_require__("Px5z");
var Modal_module_default = /*#__PURE__*/__webpack_require__.n(Modal_module);

// EXTERNAL MODULE: ./components/Other/SocialAuth/Button/Button.module.scss
var Button_module = __webpack_require__("eCyn");
var Button_module_default = /*#__PURE__*/__webpack_require__.n(Button_module);

// CONCATENATED MODULE: ./components/Other/SocialAuth/Button/Button.tsx
var __jsx = external_react_default.a.createElement;



const SocialButton = ({
  provider
}) => {
  return /*#__PURE__*/external_react_default.a.createElement("a", {
    href: `https://api.tropicalt.ca/connect/${provider}`,
    className: Button_module_default.a.link
  }, /*#__PURE__*/external_react_default.a.createElement("button", {
    className: Button_module_default.a[provider],
    type: "button"
  }, provider));
};

/* harmony default export */ var Button = (SocialButton);
// CONCATENATED MODULE: ./components/Other/SocialAuth/Modal.tsx
var Modal_jsx = external_react_default.a.createElement;




const ToggleContent = ({
  toggle,
  content
}) => {
  const {
    0: isShown,
    1: setIsShown
  } = Object(external_react_["useState"])(false);

  const hide = () => setIsShown(false);

  const show = () => setIsShown(true);

  return /*#__PURE__*/external_react_default.a.createElement(external_react_default.a.Fragment, null, toggle(show), isShown && content(hide));
};
const Modal = ({
  children
}) => external_react_dom_default.a.createPortal( /*#__PURE__*/external_react_default.a.createElement("div", {
  className: Modal_module_default.a.modalOverlay
}, /*#__PURE__*/external_react_default.a.createElement("div", {
  className: Modal_module_default.a.modal
}, children)), document.getElementById('__next'));

const Toggle = () => {
  return /*#__PURE__*/external_react_default.a.createElement(ToggleContent, {
    toggle: show => /*#__PURE__*/external_react_default.a.createElement("button", {
      className: Modal_module_default.a.submit,
      onClick: event => {
        event.preventDefault();
        show(event);
      }
    }, "Social"),
    content: hide => /*#__PURE__*/external_react_default.a.createElement(Modal, null, /*#__PURE__*/external_react_default.a.createElement(Button, {
      provider: "facebook"
    }), /*#__PURE__*/external_react_default.a.createElement(Button, {
      provider: "twitter"
    }), /*#__PURE__*/external_react_default.a.createElement(Button, {
      provider: "google"
    }), /*#__PURE__*/external_react_default.a.createElement(Button, {
      provider: "github"
    }), /*#__PURE__*/external_react_default.a.createElement("h2", null, "Thanks for reaching out"), /*#__PURE__*/external_react_default.a.createElement("p", null, `I'll get back to you shortly.`), /*#__PURE__*/external_react_default.a.createElement("button", {
      onClick: hide
    }, "Close"))
  });
};

/* harmony default export */ var SocialAuth_Modal = (Toggle);
Modal.displayName = 'Modal';
// CONCATENATED MODULE: ./pages/login.tsx
var login_jsx = external_react_default.a.createElement;




const SignUp = authorization => {
  return /*#__PURE__*/external_react_default.a.createElement(external_react_default.a.Fragment, null, !authorization && /*#__PURE__*/external_react_default.a.createElement("h1", null, "Fuck Yeah Authenticated"), /*#__PURE__*/external_react_default.a.createElement(SocialAuth_Modal, null));
};

/* harmony default export */ var login = __webpack_exports__["default"] = (SignUp);

SignUp.getInitialProps = ctx => {
  const {
    authorization
  } = Object(external_nookies_["parseCookies"])(ctx);
  const {
    token
  } = ctx.query;
  return {
    authorization: authorization || token
  };
};

/***/ }),

/***/ "Px5z":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"modalOverlay": "Modal_modalOverlay__1ZYqc",
	"modal": "Modal_modal__2Ip0L"
};


/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "eCyn":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"link": "Button_link__3UvT9",
	"facebook": "Button_facebook__2yMaA",
	"twitter": "Button_twitter__6-f7-",
	"github": "Button_github__3Qtgg",
	"google": "Button_google__3CUQk"
};


/***/ }),

/***/ "faye":
/***/ (function(module, exports) {

module.exports = require("react-dom");

/***/ }),

/***/ "kG9d":
/***/ (function(module, exports) {

module.exports = require("nookies");

/***/ })

/******/ });